import { NextResponse } from 'next/server'
import { createClient as createSupabaseClient } from '@supabase/supabase-js'

function getStripe() {
  const key = process.env.STRIPE_SECRET_KEY
  if (!key) return null
  const Stripe = require('stripe')
  return new Stripe(key, { apiVersion: '2024-06-20' })
}

const supabase = createSupabaseClient(
  'https://mynwfkgksqqwlqowlscj.supabase.co',
  process.env.SUPABASE_SERVICE_ROLE_KEY || ''
)

export async function POST(req) {
  const stripe = getStripe()
  if (!stripe) return NextResponse.json({ error: 'Not configured' }, { status: 503 })

  const body = await req.text()
  const sig = req.headers.get('stripe-signature')
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET

  let event
  try {
    event = webhookSecret ? stripe.webhooks.constructEvent(body, sig, webhookSecret) : JSON.parse(body)
  } catch (err) {
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 })
  }

  const session = event.data?.object
  const tenantId = session?.metadata?.tenantId || session?.subscription?.metadata?.tenantId

  switch (event.type) {
    case 'checkout.session.completed': {
      if (!tenantId) break
      const sub = await stripe.subscriptions.retrieve(session.subscription)
      await supabase.from('subscriptions').update({
        status: 'active',
        stripe_customer_id: session.customer,
        stripe_subscription_id: session.subscription,
        stripe_price_id: sub.items.data[0]?.price.id,
        current_period_start: new Date(sub.current_period_start * 1000).toISOString(),
        current_period_end: new Date(sub.current_period_end * 1000).toISOString(),
        updated_at: new Date().toISOString(),
      }).eq('tenant_id', tenantId)
      break
    }
    case 'invoice.payment_failed': {
      if (!tenantId) break
      await supabase.from('subscriptions').update({ status: 'past_due', updated_at: new Date().toISOString() }).eq('tenant_id', tenantId)
      break
    }
    case 'customer.subscription.deleted': {
      const tid = session?.metadata?.tenantId
      if (!tid) break
      await supabase.from('subscriptions').update({ status: 'canceled', updated_at: new Date().toISOString() }).eq('stripe_subscription_id', session.id)
      break
    }
    case 'customer.subscription.updated': {
      const tid = session?.metadata?.tenantId
      if (!tid) break
      await supabase.from('subscriptions').update({
        status: session.status,
        cancel_at_period_end: session.cancel_at_period_end,
        current_period_end: new Date(session.current_period_end * 1000).toISOString(),
        updated_at: new Date().toISOString(),
      }).eq('stripe_subscription_id', session.id)
      break
    }
  }

  return NextResponse.json({ received: true })
}
