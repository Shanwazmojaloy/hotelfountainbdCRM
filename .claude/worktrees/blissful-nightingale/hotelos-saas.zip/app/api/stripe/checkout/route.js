import { NextResponse } from 'next/server'
import { PLANS } from '@/lib/plans'

function getStripe() {
  const key = process.env.STRIPE_SECRET_KEY
  if (!key) return null
  const Stripe = require('stripe')
  return new Stripe(key, { apiVersion: '2024-06-20' })
}

export async function POST(req) {
  const stripe = getStripe()
  if (!stripe) {
    return NextResponse.json({ error: 'Stripe is not configured. Please add STRIPE_SECRET_KEY to your environment variables.' }, { status: 503 })
  }

  const { planId, tenantId, userEmail } = await req.json()
  const plan = PLANS[planId]
  if (!plan) return NextResponse.json({ error: 'Invalid plan' }, { status: 400 })
  if (!plan.priceId) return NextResponse.json({ error: `Stripe price ID not configured for ${plan.name} plan. Add NEXT_PUBLIC_STRIPE_${planId.toUpperCase()}_PRICE_ID to env vars.` }, { status: 503 })

  const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'https://hotelos.vercel.app'

  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      customer_email: userEmail,
      line_items: [{ price: plan.priceId, quantity: 1 }],
      success_url: `${appUrl}/dashboard/billing?success=1&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${appUrl}/dashboard/billing?canceled=1`,
      metadata: { tenantId, planId },
      subscription_data: { metadata: { tenantId, planId } },
    })
    return NextResponse.json({ url: session.url })
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
