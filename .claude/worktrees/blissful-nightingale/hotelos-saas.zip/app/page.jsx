'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'

const FEATURES = [
  { icon: '🏨', title: 'Multi-Tenant CRM', desc: 'Each hotel gets its own fully isolated database. Your data never mixes with others.' },
  { icon: '🔑', title: 'Role-Based Access', desc: 'Owner, Manager, Front Desk, Housekeeping — each role sees exactly what they need.' },
  { icon: '📊', title: 'Live Dashboard', desc: 'Real-time occupancy, revenue, and guest stats. Watch your hotel breathe.' },
  { icon: '🧾', title: 'Reservations & Billing', desc: 'Check-in, check-out, invoices, partial payments, and outstanding balances.' },
  { icon: '🎨', title: 'White-Label', desc: 'Your hotel name, your logo, your brand colors. No HotelOS branding visible to your staff.' },
  { icon: '🌐', title: 'Custom Domain', desc: 'Run your CRM on crm.yourhotel.com with a simple CNAME record.' },
]

const TESTIMONIALS = [
  { name: 'Rahim Uddin', hotel: 'Hotel Pearl, Dhaka', text: 'We switched from Excel in week one. Now our entire 60-room property runs on HotelOS. The billing module alone saved us 4 hours a day.', stars: 5 },
  { name: 'Priya Sharma', hotel: 'The Lotus Suites, Mumbai', text: 'The white-label feature means our staff think they\'re using our own system. Absolutely seamless. Setup took 10 minutes.', stars: 5 },
  { name: 'Carlos Mendez', hotel: 'Playa Vista Hotel', text: 'Enterprise plan with custom domain was exactly what we needed for our 200-room resort. Support is outstanding.', stars: 5 },
]

const FAQS = [
  { q: 'Is my hotel data isolated from others?', a: 'Yes, completely. Every hotel tenant has its own isolated data partition with row-level security. Your guest records, reservations, and billing are never shared.' },
  { q: 'Can I try before paying?', a: 'Every account starts with a free 14-day trial. No credit card required to sign up.' },
  { q: 'How does the custom domain work?', a: 'On Pro and Enterprise plans, you can point a subdomain (e.g. crm.yourhotel.com) to our servers via a CNAME record. SSL is automatic.' },
  { q: 'Can I change plans later?', a: 'Absolutely. Upgrade or downgrade anytime from your billing page. Changes take effect immediately.' },
  { q: 'What payment methods do you accept?', a: 'All major credit/debit cards via Stripe. Visa, Mastercard, Amex, and more.' },
  { q: 'How many staff accounts can I create?', a: 'Starter: 3, Pro: 15, Enterprise: unlimited. Each staff member gets their own role-based login.' },
]

export default function LandingPage() {
  const [billing, setBilling] = useState('monthly')
  const [openFaq, setOpenFaq] = useState(null)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const prices = {
    starter: billing === 'monthly' ? 29 : 23,
    pro: billing === 'monthly' ? 79 : 63,
    enterprise: billing === 'monthly' ? 199 : 159,
  }

  return (
    <div style={{ background: 'var(--bg)', color: 'var(--white)', fontFamily: "'DM Sans', system-ui, sans-serif" }}>
      {/* NAV */}
      <nav style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
        padding: '0 2rem',
        background: scrolled ? 'rgba(7,9,14,0.95)' : 'transparent',
        backdropFilter: scrolled ? 'blur(12px)' : 'none',
        borderBottom: scrolled ? '1px solid var(--border)' : '1px solid transparent',
        transition: 'all .3s',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        height: '64px',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span style={{ fontSize: '22px' }}>🏨</span>
          <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '22px', fontWeight: 600, color: 'var(--gold)' }}>HotelOS</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
          <a href="#features" style={{ color: 'var(--silver)', textDecoration: 'none', fontSize: '14px' }}>Features</a>
          <a href="#pricing" style={{ color: 'var(--silver)', textDecoration: 'none', fontSize: '14px' }}>Pricing</a>
          <a href="#faq" style={{ color: 'var(--silver)', textDecoration: 'none', fontSize: '14px' }}>FAQ</a>
          <Link href="/auth/login" style={{ color: 'var(--white)', textDecoration: 'none', fontSize: '14px' }}>Sign in</Link>
          <Link href="/auth/signup" style={{
            padding: '8px 20px', background: 'var(--gold)', color: '#07090E',
            borderRadius: '6px', textDecoration: 'none', fontSize: '14px', fontWeight: 600,
          }}>Start free trial</Link>
        </div>
      </nav>

      {/* HERO */}
      <section style={{
        minHeight: '100vh', display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', textAlign: 'center',
        padding: '120px 2rem 80px',
        background: 'radial-gradient(ellipse 80% 60% at 50% -10%, rgba(200,169,110,0.12) 0%, transparent 70%)',
      }}>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: '8px',
          padding: '6px 16px', borderRadius: '100px',
          border: '1px solid var(--border)', marginBottom: '32px',
          fontSize: '13px', color: 'var(--gold)',
          background: 'rgba(200,169,110,0.07)',
        }}>
          <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: 'var(--success)', display: 'inline-block', animation: 'pulse 2s infinite' }} />
          14-day free trial · No credit card required
        </div>
        <h1 style={{
          fontFamily: "'Cormorant Garamond', serif",
          fontSize: 'clamp(48px, 8vw, 96px)', fontWeight: 300, lineHeight: 1.05,
          marginBottom: '24px', letterSpacing: '-0.02em',
        }}>
          Your Hotel.<br />
          <span style={{ color: 'var(--gold)', fontStyle: 'italic' }}>Your System.</span>
        </h1>
        <p style={{ fontSize: '18px', color: 'var(--silver)', maxWidth: '540px', lineHeight: 1.6, marginBottom: '40px' }}>
          A fully white-labeled hotel management platform. Reservations, billing, housekeeping, staff — all in one CRM built for your property.
        </p>
        <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap', justifyContent: 'center' }}>
          <Link href="/auth/signup" style={{
            padding: '14px 32px', background: 'var(--gold)', color: '#07090E',
            borderRadius: '8px', textDecoration: 'none', fontSize: '16px', fontWeight: 600,
            transition: 'opacity .2s',
          }}>Get started free →</Link>
          <a href="#features" style={{
            padding: '14px 32px', border: '1px solid var(--border)',
            color: 'var(--white)', borderRadius: '8px', textDecoration: 'none',
            fontSize: '16px', background: 'transparent',
          }}>See features</a>
        </div>
        {/* Stats */}
        <div style={{ display: 'flex', gap: '48px', marginTop: '80px', flexWrap: 'wrap', justifyContent: 'center' }}>
          {[['500+', 'Hotels running'], ['99.9%', 'Uptime SLA'], ['14 days', 'Free trial'], ['24/7', 'Support']].map(([n, l]) => (
            <div key={n} style={{ textAlign: 'center' }}>
              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '36px', fontWeight: 600, color: 'var(--gold)' }}>{n}</div>
              <div style={{ fontSize: '13px', color: 'var(--silver)' }}>{l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" style={{ padding: '100px 2rem', maxWidth: '1100px', margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '64px' }}>
          <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '48px', fontWeight: 400, marginBottom: '16px' }}>
            Everything your hotel needs
          </h2>
          <p style={{ color: 'var(--silver)', fontSize: '16px' }}>Built for hoteliers, by hoteliers. Every feature you need, nothing you don't.</p>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '24px' }}>
          {FEATURES.map(f => (
            <div key={f.title} style={{
              padding: '32px', borderRadius: '12px',
              border: '1px solid var(--border)', background: 'var(--bg2)',
              transition: 'border-color .2s, transform .2s',
            }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--gold)'; e.currentTarget.style.transform = 'translateY(-2px)' }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.transform = 'none' }}
            >
              <div style={{ fontSize: '32px', marginBottom: '16px' }}>{f.icon}</div>
              <h3 style={{ fontSize: '18px', fontWeight: 600, marginBottom: '8px' }}>{f.title}</h3>
              <p style={{ color: 'var(--silver)', fontSize: '14px', lineHeight: 1.6 }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" style={{ padding: '100px 2rem', background: 'var(--bg2)' }}>
        <div style={{ maxWidth: '1000px', margin: '0 auto', textAlign: 'center' }}>
          <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '48px', fontWeight: 400, marginBottom: '16px' }}>
            Simple, transparent pricing
          </h2>
          <p style={{ color: 'var(--silver)', marginBottom: '40px' }}>Start with a 14-day free trial. No credit card required.</p>

          {/* Toggle */}
          <div style={{ display: 'inline-flex', background: 'var(--bg3)', borderRadius: '8px', padding: '4px', marginBottom: '48px', gap: '4px' }}>
            {['monthly', 'yearly'].map(b => (
              <button key={b} onClick={() => setBilling(b)} style={{
                padding: '8px 24px', borderRadius: '6px', border: 'none', cursor: 'pointer',
                background: billing === b ? 'var(--gold)' : 'transparent',
                color: billing === b ? '#07090E' : 'var(--silver)',
                fontWeight: 600, fontSize: '14px', transition: 'all .2s',
              }}>
                {b === 'monthly' ? 'Monthly' : 'Yearly (save 20%)'}
              </button>
            ))}
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '24px' }}>
            {[
              { id: 'starter', name: 'Starter', price: prices.starter, color: '#4A8CCA', rooms: 30, staff: 3, highlight: false },
              { id: 'pro', name: 'Pro', price: prices.pro, color: 'var(--gold)', rooms: 150, staff: 15, highlight: true },
              { id: 'enterprise', name: 'Enterprise', price: prices.enterprise, color: '#9B7DD4', rooms: '∞', staff: '∞', highlight: false },
            ].map(p => (
              <div key={p.id} style={{
                padding: '40px 32px', borderRadius: '16px',
                border: p.highlight ? `2px solid var(--gold)` : '1px solid var(--border)',
                background: p.highlight ? 'rgba(200,169,110,0.05)' : 'var(--bg)',
                position: 'relative', textAlign: 'left',
              }}>
                {p.highlight && (
                  <div style={{
                    position: 'absolute', top: '-14px', left: '50%', transform: 'translateX(-50%)',
                    background: 'var(--gold)', color: '#07090E', padding: '4px 16px',
                    borderRadius: '100px', fontSize: '12px', fontWeight: 700, whiteSpace: 'nowrap',
                  }}>MOST POPULAR</div>
                )}
                <div style={{ color: p.color, fontWeight: 700, fontSize: '13px', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.1em' }}>{p.name}</div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: '4px', marginBottom: '24px' }}>
                  <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '52px', fontWeight: 500 }}>${p.price}</span>
                  <span style={{ color: 'var(--silver)', fontSize: '14px' }}>/mo</span>
                </div>
                <div style={{ marginBottom: '32px' }}>
                  {[
                    `${p.rooms} rooms`, `${p.staff} staff accounts`,
                    'Full CRM access', 'Custom branding',
                    ...(p.id !== 'starter' ? ['Custom domain', 'Priority support'] : []),
                    ...(p.id === 'enterprise' ? ['White-label', 'API access'] : []),
                  ].map(f => (
                    <div key={f} style={{ display: 'flex', gap: '10px', alignItems: 'center', marginBottom: '10px', fontSize: '14px', color: 'var(--silver)' }}>
                      <span style={{ color: 'var(--success)' }}>✓</span> {f}
                    </div>
                  ))}
                </div>
                <Link href={`/auth/signup?plan=${p.id}`} style={{
                  display: 'block', textAlign: 'center', padding: '12px',
                  background: p.highlight ? 'var(--gold)' : 'transparent',
                  border: p.highlight ? 'none' : '1px solid var(--border)',
                  color: p.highlight ? '#07090E' : 'var(--white)',
                  borderRadius: '8px', textDecoration: 'none', fontWeight: 600, fontSize: '14px',
                  transition: 'opacity .2s',
                }}>
                  Start free trial →
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section style={{ padding: '100px 2rem', maxWidth: '1100px', margin: '0 auto' }}>
        <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '48px', fontWeight: 400, textAlign: 'center', marginBottom: '64px' }}>
          Loved by hoteliers
        </h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '24px' }}>
          {TESTIMONIALS.map(t => (
            <div key={t.name} style={{ padding: '32px', borderRadius: '12px', border: '1px solid var(--border)', background: 'var(--bg2)' }}>
              <div style={{ color: 'var(--gold)', marginBottom: '16px', fontSize: '18px' }}>{'★'.repeat(t.stars)}</div>
              <p style={{ color: 'var(--white)', lineHeight: 1.6, marginBottom: '24px', fontSize: '15px', fontStyle: 'italic' }}>"{t.text}"</p>
              <div>
                <div style={{ fontWeight: 600, fontSize: '14px' }}>{t.name}</div>
                <div style={{ color: 'var(--silver)', fontSize: '13px' }}>{t.hotel}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" style={{ padding: '100px 2rem', background: 'var(--bg2)' }}>
        <div style={{ maxWidth: '700px', margin: '0 auto' }}>
          <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '48px', fontWeight: 400, textAlign: 'center', marginBottom: '64px' }}>
            Common questions
          </h2>
          {FAQS.map((f, i) => (
            <div key={i} style={{ borderBottom: '1px solid var(--border)', marginBottom: '0' }}>
              <button onClick={() => setOpenFaq(openFaq === i ? null : i)} style={{
                width: '100%', textAlign: 'left', padding: '20px 0',
                background: 'none', border: 'none', cursor: 'pointer',
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                color: 'var(--white)', fontSize: '15px', fontWeight: 500,
              }}>
                {f.q}
                <span style={{ color: 'var(--gold)', fontSize: '20px', transition: 'transform .2s', transform: openFaq === i ? 'rotate(45deg)' : 'none' }}>+</span>
              </button>
              {openFaq === i && (
                <div style={{ paddingBottom: '20px', color: 'var(--silver)', fontSize: '14px', lineHeight: 1.7 }}>{f.a}</div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section style={{
        padding: '120px 2rem', textAlign: 'center',
        background: 'radial-gradient(ellipse 60% 80% at 50% 50%, rgba(200,169,110,0.08) 0%, transparent 70%)',
      }}>
        <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 'clamp(36px, 6vw, 72px)', fontWeight: 300, marginBottom: '24px' }}>
          Ready to run your hotel<br />
          <span style={{ color: 'var(--gold)', fontStyle: 'italic' }}>like it's 2025?</span>
        </h2>
        <p style={{ color: 'var(--silver)', fontSize: '18px', marginBottom: '40px' }}>
          Join 500+ hotels. Your first 14 days are completely free.
        </p>
        <Link href="/auth/signup" style={{
          display: 'inline-block', padding: '16px 48px', background: 'var(--gold)',
          color: '#07090E', borderRadius: '8px', textDecoration: 'none',
          fontSize: '18px', fontWeight: 700,
        }}>
          Create your hotel CRM →
        </Link>
      </section>

      {/* FOOTER */}
      <footer style={{ borderTop: '1px solid var(--border)', padding: '40px 2rem', textAlign: 'center', color: 'var(--silver)', fontSize: '13px' }}>
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '8px', marginBottom: '16px' }}>
          <span>🏨</span>
          <span style={{ fontFamily: "'Cormorant Garamond', serif", color: 'var(--gold)', fontSize: '18px' }}>HotelOS</span>
        </div>
        <p>© {new Date().getFullYear()} HotelOS. Built for hoteliers everywhere.</p>
      </footer>
    </div>
  )
}
