'use client'
import { useState, useContext, useEffect } from 'react'
import { TenantContext } from '../layout'
import { createClient } from '@/lib/supabase'

const TABS = ['Branding', 'Staff', 'Domain', 'Danger Zone']
const ROLES_LIST = ['owner', 'manager', 'receptionist', 'housekeeping', 'accountant']
const COLORS = ['#C8A96E', '#4A8CCA', '#3DBA8C', '#9B7DD4', '#D95F5F', '#E5A84A', '#5AB4D4', '#E87D4A']

export default function SettingsPage() {
  const ctx = useContext(TenantContext)
  const [tab, setTab] = useState('Branding')
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState({ text: '', type: '' })
  const [staffList, setStaffList] = useState([])
  const [inviteEmail, setInviteEmail] = useState('')
  const [inviteRole, setInviteRole] = useState('receptionist')
  const [inviteLoading, setInviteLoading] = useState(false)

  // Branding state
  const [hotelName, setHotelName] = useState('')
  const [color, setColor] = useState('#C8A96E')
  const [customColor, setCustomColor] = useState('')
  const [currency, setCurrency] = useState('BDT')
  const [customDomain, setCustomDomain] = useState('')
  const [timezone, setTimezone] = useState('Asia/Dhaka')

  useEffect(() => {
    if (!ctx?.tenant) return
    setHotelName(ctx.tenant.hotel_name || '')
    setColor(ctx.tenant.primary_color || '#C8A96E')
    setCurrency(ctx.tenant.currency || 'BDT')
    setCustomDomain(ctx.tenant.custom_domain || '')
    setTimezone(ctx.tenant.timezone || 'Asia/Dhaka')
    loadStaff()
  }, [ctx?.tenant])

  const loadStaff = async () => {
    if (!ctx?.tenant) return
    const sb = createClient()
    const { data } = await sb.from('tenant_users').select('*').eq('tenant_id', ctx.tenant.id)
    setStaffList(data || [])
  }

  const saveBranding = async () => {
    setSaving(true)
    const sb = createClient()
    const { error } = await sb.from('tenants').update({
      hotel_name: hotelName,
      primary_color: customColor || color,
      currency, timezone,
    }).eq('id', ctx.tenant.id)
    setSaving(false)
    if (error) setMsg({ text: error.message, type: 'error' })
    else setMsg({ text: 'Branding saved! Refresh to see changes.', type: 'success' })
    setTimeout(() => setMsg({ text: '', type: '' }), 4000)
  }

  const saveDomain = async () => {
    setSaving(true)
    const sb = createClient()
    await sb.from('tenants').update({ custom_domain: customDomain }).eq('id', ctx.tenant.id)
    setSaving(false)
    setMsg({ text: 'Domain updated!', type: 'success' })
    setTimeout(() => setMsg({ text: '', type: '' }), 3000)
  }

  const inviteStaff = async () => {
    if (!inviteEmail) return
    setInviteLoading(true)
    const sb = createClient()
    // Create staff record (they'll need to sign up and get linked)
    const { error } = await sb.from('tenant_users').insert({
      tenant_id: ctx.tenant.id,
      email: inviteEmail,
      role: inviteRole,
      name: inviteEmail.split('@')[0],
      is_owner: false,
    })
    setInviteLoading(false)
    if (error) setMsg({ text: 'Failed: ' + error.message, type: 'error' })
    else {
      setMsg({ text: `${inviteEmail} added as ${inviteRole}. They need to sign up using this email.`, type: 'success' })
      setInviteEmail('')
      loadStaff()
    }
    setTimeout(() => setMsg({ text: '', type: '' }), 5000)
  }

  const removeStaff = async (staffId) => {
    if (!confirm('Remove this staff member?')) return
    const sb = createClient()
    await sb.from('tenant_users').delete().eq('id', staffId)
    loadStaff()
  }

  if (!ctx) return null
  const finalColor = customColor || color

  const ROLE_LABELS = { owner: '👑 Owner', manager: '🎯 Manager', receptionist: '🖥 Receptionist', housekeeping: '🧹 Housekeeping', accountant: '📊 Accountant' }
  const ROLE_PERMS = {
    owner: 'Full access — all modules, settings, billing',
    manager: 'All modules except billing & settings',
    receptionist: 'Dashboard, rooms, reservations, guests, billing',
    housekeeping: 'Dashboard and housekeeping only',
    accountant: 'Dashboard, billing and reports only',
  }

  return (
    <div>
      <div style={{ marginBottom: '32px' }}>
        <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '32px', fontWeight: 400, marginBottom: '4px' }}>Settings</h1>
        <p style={{ color: 'var(--silver)', fontSize: '14px' }}>Manage your hotel's configuration.</p>
      </div>

      {msg.text && (
        <div style={{ padding: '12px 16px', borderRadius: '8px', marginBottom: '24px', fontSize: '14px', background: msg.type === 'error' ? 'rgba(217,95,95,0.1)' : 'rgba(61,186,140,0.1)', border: `1px solid ${msg.type === 'error' ? 'var(--danger)' : 'var(--success)'}`, color: msg.type === 'error' ? 'var(--danger)' : 'var(--success)' }}>
          {msg.text}
        </div>
      )}

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '4px', marginBottom: '32px', background: 'var(--bg2)', padding: '4px', borderRadius: '10px', width: 'fit-content', border: '1px solid var(--border)' }}>
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            padding: '8px 20px', borderRadius: '7px', border: 'none', cursor: 'pointer', fontSize: '14px', fontWeight: 500, transition: 'all .15s',
            background: tab === t ? (t === 'Danger Zone' ? 'var(--danger)' : finalColor) : 'transparent',
            color: tab === t ? (t === 'Danger Zone' ? '#fff' : '#07090E') : 'var(--silver)',
          }}>{t}</button>
        ))}
      </div>

      {/* BRANDING TAB */}
      {tab === 'Branding' && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: '24px' }}>
          <div style={{ padding: '32px', background: 'var(--bg2)', borderRadius: '14px', border: '1px solid var(--border)' }}>
            <h3 style={{ fontWeight: 600, marginBottom: '24px' }}>Hotel Identity</h3>
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', fontSize: '13px', color: 'var(--silver)', marginBottom: '6px', fontWeight: 500 }}>Hotel Name</label>
              <input value={hotelName} onChange={e => setHotelName(e.target.value)} style={{ width: '100%', padding: '11px 14px', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--white)', fontSize: '14px', outline: 'none', boxSizing: 'border-box' }} />
            </div>
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', fontSize: '13px', color: 'var(--silver)', marginBottom: '8px', fontWeight: 500 }}>Brand Color</label>
              <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', marginBottom: '12px' }}>
                {COLORS.map(c => <button key={c} onClick={() => { setColor(c); setCustomColor('') }} style={{ width: '36px', height: '36px', borderRadius: '50%', background: c, border: `3px solid ${color === c && !customColor ? 'white' : 'transparent'}`, cursor: 'pointer' }} />)}
              </div>
              <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                <input type="color" value={finalColor} onChange={e => setCustomColor(e.target.value)} style={{ width: '44px', height: '36px', border: 'none', borderRadius: '6px', cursor: 'pointer', background: 'none' }} />
                <input value={finalColor} onChange={e => setCustomColor(e.target.value)} style={{ flex: 1, padding: '8px 12px', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--white)', fontSize: '13px', outline: 'none', fontFamily: 'monospace' }} />
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '24px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '13px', color: 'var(--silver)', marginBottom: '6px', fontWeight: 500 }}>Currency</label>
                <select value={currency} onChange={e => setCurrency(e.target.value)} style={{ width: '100%', padding: '10px 12px', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--white)', fontSize: '14px', outline: 'none' }}>
                  {['BDT', 'USD', 'EUR', 'GBP', 'INR', 'AED', 'SGD', 'JPY'].map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '13px', color: 'var(--silver)', marginBottom: '6px', fontWeight: 500 }}>Timezone</label>
                <select value={timezone} onChange={e => setTimezone(e.target.value)} style={{ width: '100%', padding: '10px 12px', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--white)', fontSize: '14px', outline: 'none' }}>
                  {['Asia/Dhaka', 'Asia/Kolkata', 'Asia/Dubai', 'Europe/London', 'America/New_York', 'Asia/Singapore', 'Asia/Tokyo'].map(tz => <option key={tz}>{tz}</option>)}
                </select>
              </div>
            </div>
            <button onClick={saveBranding} disabled={saving} style={{ padding: '12px 28px', background: finalColor, color: '#07090E', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 700, opacity: saving ? 0.7 : 1 }}>
              {saving ? 'Saving…' : 'Save Branding'}
            </button>
          </div>

          {/* Preview */}
          <div style={{ padding: '24px', background: 'var(--bg2)', borderRadius: '14px', border: '1px solid var(--border)' }}>
            <div style={{ fontSize: '12px', color: 'var(--silver)', marginBottom: '12px', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 600 }}>Preview</div>
            <div style={{ background: 'var(--bg)', borderRadius: '10px', overflow: 'hidden', border: '1px solid var(--border2)' }}>
              <div style={{ background: finalColor, padding: '12px 16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontSize: '16px' }}>🏨</span>
                <span style={{ fontWeight: 700, color: '#07090E', fontSize: '14px' }}>{hotelName || 'Your Hotel'}</span>
              </div>
              <div style={{ display: 'flex', height: '200px' }}>
                <div style={{ width: '100px', background: '#0D1117', padding: '12px 8px', borderRight: '1px solid var(--border2)' }}>
                  {['Dashboard', 'Rooms', 'Guests', 'Billing'].map((m, i) => (
                    <div key={m} style={{ padding: '5px 8px', borderRadius: '5px', fontSize: '10px', marginBottom: '3px', background: i === 0 ? `${finalColor}25` : 'transparent', color: i === 0 ? finalColor : 'var(--silver)' }}>{m}</div>
                  ))}
                </div>
                <div style={{ flex: 1, padding: '12px' }}>
                  <div style={{ fontSize: '11px', fontWeight: 700, color: finalColor, marginBottom: '8px' }}>Dashboard</div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px' }}>
                    {[['Rooms', '24', finalColor], ['Guests', '18', 'var(--success)'], ['Revenue', '82k', 'var(--gold)'], ['Tasks', '6', '#9B7DD4']].map(([l, v, c]) => (
                      <div key={l} style={{ padding: '8px', background: 'var(--bg2)', borderRadius: '6px', border: '1px solid var(--border2)' }}>
                        <div style={{ fontSize: '9px', color: 'var(--silver)' }}>{l}</div>
                        <div style={{ fontSize: '14px', fontWeight: 700, color: c }}>{v}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* STAFF TAB */}
      {tab === 'Staff' && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: '24px' }}>
          <div style={{ padding: '32px', background: 'var(--bg2)', borderRadius: '14px', border: '1px solid var(--border)' }}>
            <h3 style={{ fontWeight: 600, marginBottom: '20px' }}>Team Members ({staffList.length})</h3>
            {staffList.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '32px', color: 'var(--silver)', fontSize: '14px' }}>No staff added yet</div>
            ) : staffList.map(s => (
              <div key={s.id} style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '12px', borderRadius: '8px', border: '1px solid var(--border)', marginBottom: '8px' }}>
                <div style={{ width: '36px', height: '36px', borderRadius: '50%', background: finalColor, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, color: '#07090E', fontSize: '14px', flexShrink: 0 }}>
                  {(s.name || s.email || 'U')[0].toUpperCase()}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 600, fontSize: '14px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.name || s.email}</div>
                  <div style={{ fontSize: '12px', color: 'var(--silver)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.email}</div>
                </div>
                <span style={{ padding: '3px 10px', borderRadius: '100px', fontSize: '11px', background: `${finalColor}20`, color: finalColor, fontWeight: 600, whiteSpace: 'nowrap' }}>
                  {ROLE_LABELS[s.role] || s.role}
                </span>
                {!s.is_owner && (
                  <button onClick={() => removeStaff(s.id)} style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer', fontSize: '16px', padding: '4px' }}>✕</button>
                )}
              </div>
            ))}
          </div>

          <div style={{ padding: '32px', background: 'var(--bg2)', borderRadius: '14px', border: '1px solid var(--border)' }}>
            <h3 style={{ fontWeight: 600, marginBottom: '20px' }}>Add Staff Member</h3>
            <div style={{ marginBottom: '16px' }}>
              <label style={{ display: 'block', fontSize: '13px', color: 'var(--silver)', marginBottom: '6px' }}>Email address</label>
              <input value={inviteEmail} onChange={e => setInviteEmail(e.target.value)} placeholder="staff@yourhotel.com" type="email"
                style={{ width: '100%', padding: '10px 12px', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--white)', fontSize: '14px', outline: 'none', boxSizing: 'border-box' }} />
            </div>
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', fontSize: '13px', color: 'var(--silver)', marginBottom: '6px' }}>Role</label>
              <select value={inviteRole} onChange={e => setInviteRole(e.target.value)} style={{ width: '100%', padding: '10px 12px', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--white)', fontSize: '14px', outline: 'none' }}>
                {ROLES_LIST.filter(r => r !== 'owner').map(r => <option key={r} value={r}>{ROLE_LABELS[r]}</option>)}
              </select>
            </div>
            {inviteRole && (
              <div style={{ padding: '10px 12px', background: 'var(--bg3)', borderRadius: '8px', fontSize: '12px', color: 'var(--silver)', marginBottom: '16px', lineHeight: 1.5 }}>
                <strong style={{ color: 'var(--white)' }}>Permissions:</strong> {ROLE_PERMS[inviteRole]}
              </div>
            )}
            <button onClick={inviteStaff} disabled={inviteLoading || !inviteEmail} style={{ width: '100%', padding: '11px', background: finalColor, color: '#07090E', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 700, opacity: inviteLoading ? 0.7 : 1 }}>
              {inviteLoading ? 'Adding…' : 'Add Staff Member'}
            </button>
          </div>
        </div>
      )}

      {/* DOMAIN TAB */}
      {tab === 'Domain' && (
        <div style={{ maxWidth: '600px' }}>
          <div style={{ padding: '32px', background: 'var(--bg2)', borderRadius: '14px', border: '1px solid var(--border)', marginBottom: '20px' }}>
            <h3 style={{ fontWeight: 600, marginBottom: '8px' }}>Custom Domain</h3>
            <p style={{ color: 'var(--silver)', fontSize: '14px', marginBottom: '24px', lineHeight: 1.6 }}>
              Point your own domain to your hotel CRM. Available on Pro and Enterprise plans.
            </p>
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', fontSize: '13px', color: 'var(--silver)', marginBottom: '6px' }}>Your domain</label>
              <input value={customDomain} onChange={e => setCustomDomain(e.target.value)} placeholder="crm.yourhotel.com"
                style={{ width: '100%', padding: '11px 14px', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--white)', fontSize: '14px', outline: 'none', boxSizing: 'border-box', fontFamily: 'monospace' }} />
            </div>
            <button onClick={saveDomain} style={{ padding: '11px 24px', background: finalColor, color: '#07090E', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 700 }}>
              Save Domain
            </button>
          </div>
          <div style={{ padding: '24px', background: 'var(--bg2)', borderRadius: '12px', border: '1px solid var(--border)', fontSize: '13px', color: 'var(--silver)', lineHeight: 1.7 }}>
            <strong style={{ color: 'var(--white)' }}>How to set up your domain:</strong><br />
            1. Add a CNAME record in your DNS provider<br />
            2. Point <code style={{ background: 'var(--bg3)', padding: '1px 6px', borderRadius: '4px' }}>crm.yourhotel.com</code> → <code style={{ background: 'var(--bg3)', padding: '1px 6px', borderRadius: '4px' }}>app.hotelos.com</code><br />
            3. SSL certificate is provisioned automatically (24–48h)
          </div>
        </div>
      )}

      {/* DANGER ZONE */}
      {tab === 'Danger Zone' && (
        <div style={{ maxWidth: '560px' }}>
          <div style={{ padding: '32px', background: 'rgba(217,95,95,0.07)', borderRadius: '14px', border: '1px solid var(--danger)' }}>
            <h3 style={{ color: 'var(--danger)', fontWeight: 600, marginBottom: '8px' }}>Delete Hotel Account</h3>
            <p style={{ color: 'var(--silver)', fontSize: '14px', lineHeight: 1.6, marginBottom: '20px' }}>
              Permanently deletes your hotel, all rooms, guests, reservations, and billing data. This cannot be undone.
            </p>
            <button onClick={() => alert('Please contact support@hotelos.app to delete your account.')} style={{ padding: '11px 24px', background: 'var(--danger)', color: '#fff', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 700 }}>
              Request Account Deletion
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
