'use client'
import { useState, useEffect, createContext, useContext } from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase'

export const TenantContext = createContext(null)
export const useTenant = () => useContext(TenantContext)

const NAV = [
  { href: '/dashboard', label: 'Dashboard', icon: '◈' },
  { href: '/dashboard/app', label: 'Hotel CRM', icon: '🏨' },
  { href: '/dashboard/billing', label: 'Billing', icon: '💳' },
  { href: '/dashboard/settings', label: 'Settings', icon: '⚙️' },
]

export default function DashboardLayout({ children }) {
  const router = useRouter()
  const pathname = usePathname()
  const [tenant, setTenant] = useState(null)
  const [subscription, setSubscription] = useState(null)
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [sidebarOpen, setSidebarOpen] = useState(true)

  useEffect(() => {
    const load = async () => {
      const sb = createClient()
      const { data: { user: u } } = await sb.auth.getUser()
      if (!u) { router.push('/auth/login'); return }
      setUser(u)
      // Get tenant via tenant_users or owner
      let tenantId
      const { data: tu } = await sb.from('tenant_users').select('tenant_id,role').eq('user_id', u.id).single()
      if (tu) tenantId = tu.tenant_id
      if (!tenantId) {
        const { data: t } = await sb.from('tenants').select('id').eq('owner_id', u.id).single()
        if (t) tenantId = t.id
      }
      if (!tenantId) { router.push('/auth/signup'); return }
      const { data: t } = await sb.from('tenants').select('*').eq('id', tenantId).single()
      if (!t?.onboarding_complete) { router.push('/auth/onboarding'); return }
      setTenant(t)
      const { data: sub } = await sb.from('subscriptions').select('*').eq('tenant_id', tenantId).single()
      setSubscription(sub)
      setLoading(false)
    }
    load()
  }, [])

  const logout = async () => {
    const sb = createClient()
    await sb.auth.signOut()
    router.push('/')
  }

  if (loading) return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ width: '40px', height: '40px', border: '3px solid var(--border)', borderTop: '3px solid var(--gold)', borderRadius: '50%', animation: 'spin 1s linear infinite', margin: '0 auto 16px' }} />
        <p style={{ color: 'var(--silver)', fontSize: '14px' }}>Loading your hotel…</p>
      </div>
    </div>
  )

  const color = tenant?.primary_color || '#C8A96E'
  const trialDays = subscription?.status === 'trialing' && subscription?.trial_ends_at
    ? Math.max(0, Math.ceil((new Date(subscription.trial_ends_at) - new Date()) / 86400000))
    : null

  return (
    <TenantContext.Provider value={{ tenant, subscription, user, color, reload: async () => {} }}>
      <div style={{ display: 'flex', minHeight: '100vh', background: 'var(--bg)' }}>
        {/* SIDEBAR */}
        <aside style={{
          width: sidebarOpen ? '240px' : '64px', flexShrink: 0,
          background: 'var(--bg2)', borderRight: '1px solid var(--border)',
          display: 'flex', flexDirection: 'column',
          transition: 'width .25s', overflow: 'hidden',
        }}>
          {/* Logo / Hotel Name */}
          <div style={{ padding: '20px', borderBottom: '1px solid var(--border)', minHeight: '72px', display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '18px', flexShrink: 0 }}>🏨</div>
            {sidebarOpen && (
              <div style={{ overflow: 'hidden' }}>
                <div style={{ fontWeight: 700, fontSize: '14px', color: color, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{tenant?.hotel_name}</div>
                <div style={{ fontSize: '11px', color: 'var(--silver)', textTransform: 'capitalize' }}>{subscription?.plan} · {subscription?.status}</div>
              </div>
            )}
          </div>

          {/* Trial banner */}
          {sidebarOpen && trialDays !== null && trialDays <= 7 && (
            <div style={{ margin: '12px', padding: '10px 12px', background: `${color}15`, border: `1px solid ${color}40`, borderRadius: '8px', fontSize: '12px' }}>
              <div style={{ color, fontWeight: 600 }}>⏳ {trialDays} days left</div>
              <div style={{ color: 'var(--silver)', marginTop: '2px' }}>
                <Link href="/dashboard/billing" style={{ color, textDecoration: 'none', fontWeight: 600 }}>Upgrade now →</Link>
              </div>
            </div>
          )}

          {/* Nav */}
          <nav style={{ flex: 1, padding: '12px 8px' }}>
            {NAV.map(n => {
              const active = pathname === n.href || (n.href !== '/dashboard' && pathname.startsWith(n.href))
              return (
                <Link key={n.href} href={n.href} style={{
                  display: 'flex', alignItems: 'center', gap: '12px',
                  padding: '10px 12px', borderRadius: '8px', textDecoration: 'none',
                  marginBottom: '4px', transition: 'all .15s',
                  background: active ? `${color}20` : 'transparent',
                  color: active ? color : 'var(--silver)',
                  fontWeight: active ? 600 : 400, fontSize: '14px',
                }}>
                  <span style={{ fontSize: '16px', flexShrink: 0 }}>{n.icon}</span>
                  {sidebarOpen && n.label}
                </Link>
              )
            })}
          </nav>

          {/* Bottom */}
          <div style={{ padding: '12px 8px', borderTop: '1px solid var(--border)' }}>
            {sidebarOpen && (
              <div style={{ padding: '8px 12px', fontSize: '12px', color: 'var(--silver)', marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{ width: '28px', height: '28px', borderRadius: '50%', background: color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '13px', fontWeight: 700, color: '#07090E', flexShrink: 0 }}>
                  {(user?.email || 'U')[0].toUpperCase()}
                </div>
                <div style={{ overflow: 'hidden' }}>
                  <div style={{ fontWeight: 600, color: 'var(--white)', fontSize: '13px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user?.email}</div>
                </div>
              </div>
            )}
            <button onClick={logout} style={{ width: '100%', padding: '8px 12px', background: 'transparent', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--silver)', cursor: 'pointer', fontSize: '13px', display: 'flex', alignItems: 'center', gap: '8px', justifyContent: sidebarOpen ? 'flex-start' : 'center' }}>
              <span>↩</span>{sidebarOpen && 'Sign out'}
            </button>
          </div>
        </aside>

        {/* MAIN */}
        <main style={{ flex: 1, overflow: 'auto', minWidth: 0 }}>
          {/* Topbar */}
          <header style={{ height: '60px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', padding: '0 24px', gap: '16px', background: 'var(--bg2)', position: 'sticky', top: 0, zIndex: 50 }}>
            <button onClick={() => setSidebarOpen(!sidebarOpen)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--silver)', fontSize: '20px', padding: '4px' }}>☰</button>
            <div style={{ flex: 1 }} />
            {trialDays !== null && (
              <Link href="/dashboard/billing" style={{ padding: '6px 14px', background: `${color}20`, border: `1px solid ${color}40`, color, borderRadius: '100px', fontSize: '12px', fontWeight: 600, textDecoration: 'none' }}>
                Trial: {trialDays}d left · Upgrade
              </Link>
            )}
          </header>
          <div style={{ padding: '32px' }}>
            {children}
          </div>
        </main>
      </div>
    </TenantContext.Provider>
  )
}
