'use client'
import { useState, useContext } from 'react'
import { TenantContext } from '../layout'
import { PLANS } from '@/lib/plans'
import Link from 'next/link'

export default function BillingPage() {
  const ctx = useContext(TenantContext)
  const [loading, setLoading] = useState(null)
  const [msg, setMsg] = useState('')

  if (!ctx) return null
  const { tenant, subscription, color } = ctx

  const handleCheckout = async (planId) => {
    setLoading(planId); setMsg('')
    try {
      const res = await fetch('/api/stripe/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ planId, tenantId: tenant.id, userEmail: ctx.user?.email }),
      })
      const data = await res.json()
      if (data.url) window.location.href = data.url
      else setMsg(data.error || 'Something went wrong. Please contact support.')
    } catch {
      setMsg('Connection error. Please try again.')
    }
    setLoading(null)
  }

  const sub = subscription
  const plan = sub?.plan || 'starter'
  const status = sub?.status || 'trialing'
  const trialEnd = sub?.trial_ends_at ? new Date(sub.trial_ends_at) : null
  const trialDays = trialEnd ? Math.max(0, Math.ceil((trialEnd - new Date()) / 86400000)) : 0
  const periodEnd = sub?.current_period_end ? new Date(sub.current_period_end) : null

  const STATUS_COLOR = { trialing: '#E5A84A', active: 'var(--success)', past_due: 'var(--danger)', canceled: 'var(--danger)', paused: 'var(--silver)' }

  return (
    <div>
      <div style={{ marginBottom: '32px' }}>
        <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '32px', fontWeight: 400, marginBottom: '4px' }}>Billing & Subscription</h1>
        <p style={{ color: 'var(--silver)', fontSize: '14px' }}>Manage your plan and payment methods.</p>
      </div>

      {msg && (
        <div style={{ padding: '14px', background: 'rgba(217,95,95,0.1)', border: '1px solid var(--danger)', borderRadius: '8px', color: 'var(--danger)', fontSize: '14px', marginBottom: '24px' }}>{msg}</div>
      )}

      {/* Current plan card */}
      <div style={{ padding: '28px', background: 'var(--bg2)', borderRadius: '16px', border: '1px solid var(--border)', marginBottom: '32px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '16px' }}>
          <div>
            <div style={{ fontSize: '12px', color: 'var(--silver)', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Current Plan</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px' }}>
              <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '28px', fontWeight: 600, textTransform: 'capitalize' }}>{plan}</span>
              <span style={{ padding: '3px 12px', borderRadius: '100px', fontSize: '12px', fontWeight: 700, background: `${STATUS_COLOR[status]}20`, color: STATUS_COLOR[status], textTransform: 'capitalize' }}>{status}</span>
            </div>
            {status === 'trialing' && (
              <p style={{ color: 'var(--silver)', fontSize: '14px' }}>
                {trialDays > 0 ? `Trial ends in ${trialDays} days (${trialEnd?.toLocaleDateString()})` : 'Trial has ended'}
              </p>
            )}
            {status === 'active' && periodEnd && (
              <p style={{ color: 'var(--silver)', fontSize: '14px' }}>
                Next billing: {periodEnd.toLocaleDateString()}
                {sub?.cancel_at_period_end && <span style={{ color: 'var(--danger)', marginLeft: '8px' }}>· Cancels at period end</span>}
              </p>
            )}
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '40px', fontWeight: 500, color }}>
              ${PLANS[plan]?.price || 0}<span style={{ fontSize: '16px', color: 'var(--silver)', fontFamily: 'inherit' }}>/mo</span>
            </div>
          </div>
        </div>
      </div>

      {/* Plan selection */}
      <h2 style={{ fontSize: '18px', fontWeight: 600, marginBottom: '20px' }}>
        {status === 'active' ? 'Change Plan' : 'Choose a Plan'}
      </h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '20px', marginBottom: '32px' }}>
        {Object.values(PLANS).map(p => {
          const isCurrentPlan = plan === p.id && (status === 'active' || status === 'trialing')
          return (
            <div key={p.id} style={{
              padding: '32px', borderRadius: '14px',
              border: `2px solid ${isCurrentPlan ? p.color : 'var(--border)'}`,
              background: isCurrentPlan ? `${p.color}08` : 'var(--bg2)',
              position: 'relative',
            }}>
              {p.highlight && <div style={{ position: 'absolute', top: '-12px', left: '50%', transform: 'translateX(-50%)', background: p.color, color: '#07090E', padding: '3px 14px', borderRadius: '100px', fontSize: '11px', fontWeight: 700 }}>POPULAR</div>}
              <div style={{ color: p.color, fontWeight: 700, fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: '8px' }}>{p.name}</div>
              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '44px', fontWeight: 500, marginBottom: '4px' }}>${p.price}<span style={{ fontSize: '14px', color: 'var(--silver)', fontFamily: 'inherit' }}>/mo</span></div>
              <div style={{ fontSize: '13px', color: 'var(--silver)', marginBottom: '20px' }}>{p.tagline}</div>
              <div style={{ marginBottom: '24px' }}>
                {p.features.map(f => (
                  <div key={f} style={{ display: 'flex', gap: '8px', alignItems: 'center', fontSize: '13px', color: 'var(--silver)', marginBottom: '8px' }}>
                    <span style={{ color: 'var(--success)', flexShrink: 0 }}>✓</span>{f}
                  </div>
                ))}
              </div>
              {isCurrentPlan ? (
                <div style={{ padding: '10px', background: `${p.color}15`, borderRadius: '8px', textAlign: 'center', color: p.color, fontSize: '13px', fontWeight: 600 }}>
                  ✓ Current plan
                </div>
              ) : (
                <button onClick={() => handleCheckout(p.id)} disabled={loading === p.id} style={{
                  width: '100%', padding: '11px', borderRadius: '8px', border: 'none', cursor: loading === p.id ? 'not-allowed' : 'pointer',
                  background: p.highlight ? p.color : 'var(--bg3)', color: p.highlight ? '#07090E' : 'var(--white)',
                  fontWeight: 600, fontSize: '14px', opacity: loading === p.id ? 0.7 : 1,
                }}>
                  {loading === p.id ? 'Redirecting…' : status === 'active' ? `Switch to ${p.name}` : `Start with ${p.name} →`}
                </button>
              )}
            </div>
          )
        })}
      </div>

      {/* Info */}
      <div style={{ padding: '20px', background: 'var(--bg2)', borderRadius: '12px', border: '1px solid var(--border)', fontSize: '13px', color: 'var(--silver)', lineHeight: 1.6 }}>
        <strong style={{ color: 'var(--white)' }}>How billing works:</strong> You'll be redirected to Stripe's secure checkout. After payment, your subscription activates immediately. You can cancel anytime from this page. Cancellations take effect at the end of your current billing period — you won't be charged again.
      </div>
    </div>
  )
}
