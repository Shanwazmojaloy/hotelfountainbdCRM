'use client'
import { useContext } from 'react'
import dynamic from 'next/dynamic'
import Link from 'next/link'
import { TenantContext } from '../layout'

const HotelCRM = dynamic(() => import('@/components/crm/HotelCRM'), { 
  ssr: false,
  loading: () => (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '60vh' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ width: '40px', height: '40px', border: '3px solid var(--border)', borderTop: '3px solid var(--gold)', borderRadius: '50%', animation: 'spin 1s linear infinite', margin: '0 auto 16px' }} />
        <p style={{ color: 'var(--silver)', fontSize: '14px' }}>Loading Hotel CRM…</p>
      </div>
    </div>
  )
})

export default function AppPage() {
  const ctx = useContext(TenantContext)
  if (!ctx) return null

  const { subscription, tenant, color } = ctx

  // Gating: canceled subscriptions can't access
  if (subscription?.status === 'canceled') {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh' }}>
        <div style={{ textAlign: 'center', maxWidth: '420px', padding: '40px', background: 'var(--bg2)', borderRadius: '16px', border: '1px solid var(--border)' }}>
          <div style={{ fontSize: '48px', marginBottom: '16px' }}>🔒</div>
          <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '28px', marginBottom: '12px' }}>Subscription Inactive</h2>
          <p style={{ color: 'var(--silver)', fontSize: '14px', marginBottom: '24px', lineHeight: 1.6 }}>
            Your subscription has ended. Reactivate to access your hotel CRM and all your data.
          </p>
          <Link href="/dashboard/billing" style={{ display: 'inline-block', padding: '12px 28px', background: 'var(--gold)', color: '#07090E', borderRadius: '8px', textDecoration: 'none', fontWeight: 700 }}>
            Reactivate subscription →
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div style={{ margin: '-32px', height: 'calc(100vh - 60px)', overflow: 'hidden' }}>
      {/* Tenant branding bar */}
      <div style={{ padding: '8px 20px', background: 'var(--bg2)', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: '12px', fontSize: '13px' }}>
        <div style={{ width: '20px', height: '20px', borderRadius: '4px', background: color }} />
        <span style={{ color, fontWeight: 700 }}>{tenant?.hotel_name}</span>
        <span style={{ color: 'var(--silver)' }}>Hotel Management System</span>
        <div style={{ flex: 1 }} />
        <span style={{ padding: '2px 10px', borderRadius: '100px', background: `${color}20`, color, fontSize: '12px', fontWeight: 600, textTransform: 'capitalize' }}>
          {subscription?.plan} · {subscription?.status}
        </span>
      </div>
      <div style={{ height: 'calc(100% - 37px)', overflow: 'auto' }}>
        <HotelCRM />
      </div>
    </div>
  )
}
