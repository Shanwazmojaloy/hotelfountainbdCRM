'use client'
import { useState, useEffect, useContext } from 'react'
import Link from 'next/link'
import { TenantContext } from './layout'
import { createClient } from '@/lib/supabase'

export default function DashboardHome() {
  const ctx = useContext(TenantContext)
  const [stats, setStats] = useState({ rooms: 0, available: 0, occupied: 0, guests: 0, reservations: 0, todayRevenue: 0 })
  const [recentRes, setRecentRes] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!ctx?.tenant) return
    const load = async () => {
      const sb = createClient()
      const tid = ctx.tenant.id
      const [{ data: rooms }, { data: guests }, { data: res }] = await Promise.all([
        sb.from('tenant_rooms').select('status').eq('tenant_id', tid),
        sb.from('tenant_guests').select('id').eq('tenant_id', tid),
        sb.from('tenant_reservations').select('*').eq('tenant_id', tid).order('created_at', { ascending: false }).limit(5),
      ])
      const occupied = rooms?.filter(r => r.status === 'occupied').length || 0
      const available = rooms?.filter(r => r.status === 'available').length || 0
      const todayRevenue = res?.filter(r => {
        const d = new Date(r.created_at); const now = new Date()
        return d.toDateString() === now.toDateString()
      }).reduce((s, r) => s + (r.paid_amount || 0), 0) || 0
      setStats({ rooms: rooms?.length || 0, available, occupied, guests: guests?.length || 0, reservations: res?.length || 0, todayRevenue })
      setRecentRes(res || [])
      setLoading(false)
    }
    load()
  }, [ctx?.tenant])

  if (!ctx || loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '300px' }}>
      <div style={{ width: '32px', height: '32px', border: '3px solid var(--border)', borderTop: `3px solid ${ctx?.color || 'var(--gold)'}`, borderRadius: '50%', animation: 'spin 1s linear infinite' }} />
    </div>
  )

  const color = ctx.color
  const occupancy = stats.rooms ? Math.round((stats.occupied / stats.rooms) * 100) : 0

  const STAT_CARDS = [
    { label: 'Occupancy Rate', value: `${occupancy}%`, sub: `${stats.occupied}/${stats.rooms} rooms`, color, icon: '📊' },
    { label: "Today's Revenue", value: `${ctx.tenant.currency || 'BDT'} ${stats.todayRevenue.toLocaleString()}`, sub: 'Collected today', color: 'var(--success)', icon: '💰' },
    { label: 'Total Guests', value: stats.guests, sub: 'In your database', color: '#9B7DD4', icon: '👥' },
    { label: 'Available Rooms', value: stats.available, sub: `${stats.rooms} total rooms`, color: 'var(--gold)', icon: '🔑' },
  ]

  return (
    <div>
      <div style={{ marginBottom: '32px' }}>
        <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '32px', fontWeight: 400, marginBottom: '4px' }}>
          Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 17 ? 'afternoon' : 'evening'} 👋
        </h1>
        <p style={{ color: 'var(--silver)', fontSize: '14px' }}>Here's what's happening at <strong style={{ color }}>{ctx.tenant.hotel_name}</strong> today.</p>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px', marginBottom: '32px' }}>
        {STAT_CARDS.map(s => (
          <div key={s.label} style={{ padding: '24px', background: 'var(--bg2)', borderRadius: '12px', border: '1px solid var(--border)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
              <span style={{ fontSize: '24px' }}>{s.icon}</span>
              <span style={{ fontSize: '11px', color: 'var(--silver)', fontWeight: 500 }}>{s.label}</span>
            </div>
            <div style={{ fontSize: '28px', fontWeight: 700, color: s.color, marginBottom: '4px', fontFamily: "'Cormorant Garamond', serif" }}>{s.value}</div>
            <div style={{ fontSize: '12px', color: 'var(--silver)' }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Occupancy bar */}
      <div style={{ padding: '24px', background: 'var(--bg2)', borderRadius: '12px', border: '1px solid var(--border)', marginBottom: '24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '12px' }}>
          <span style={{ fontWeight: 600, fontSize: '14px' }}>Room Occupancy</span>
          <span style={{ color, fontWeight: 700 }}>{occupancy}%</span>
        </div>
        <div style={{ height: '8px', background: 'var(--bg3)', borderRadius: '4px', overflow: 'hidden' }}>
          <div style={{ height: '100%', width: `${occupancy}%`, background: color, borderRadius: '4px', transition: 'width 1s ease' }} />
        </div>
        <div style={{ display: 'flex', gap: '24px', marginTop: '12px', fontSize: '12px', color: 'var(--silver)' }}>
          <span style={{ color: 'var(--danger)' }}>● {stats.occupied} Occupied</span>
          <span style={{ color: 'var(--success)' }}>● {stats.available} Available</span>
          <span style={{ color: 'var(--silver)' }}>● {stats.rooms - stats.occupied - stats.available} Other</span>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
        {/* Recent Reservations */}
        <div style={{ padding: '24px', background: 'var(--bg2)', borderRadius: '12px', border: '1px solid var(--border)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
            <h3 style={{ fontWeight: 600, fontSize: '15px' }}>Recent Reservations</h3>
            <Link href="/dashboard/app" style={{ fontSize: '12px', color, textDecoration: 'none' }}>View all →</Link>
          </div>
          {recentRes.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '32px', color: 'var(--silver)', fontSize: '14px' }}>
              <div style={{ fontSize: '32px', marginBottom: '8px' }}>📋</div>
              No reservations yet
            </div>
          ) : recentRes.map(r => (
            <div key={r.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid var(--border2)', fontSize: '13px' }}>
              <div>
                <div style={{ fontWeight: 600 }}>Reservation</div>
                <div style={{ color: 'var(--silver)', fontSize: '12px' }}>{new Date(r.check_in).toLocaleDateString()} → {new Date(r.check_out).toLocaleDateString()}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ color, fontWeight: 600 }}>{ctx.tenant.currency} {r.total_amount}</div>
                <div style={{ padding: '2px 8px', borderRadius: '100px', fontSize: '11px', background: r.status === 'checked_in' ? 'rgba(61,186,140,0.15)' : 'rgba(200,169,110,0.15)', color: r.status === 'checked_in' ? 'var(--success)' : 'var(--gold)' }}>
                  {r.status}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Quick Actions */}
        <div style={{ padding: '24px', background: 'var(--bg2)', borderRadius: '12px', border: '1px solid var(--border)' }}>
          <h3 style={{ fontWeight: 600, fontSize: '15px', marginBottom: '20px' }}>Quick Actions</h3>
          {[
            { icon: '➕', label: 'New Reservation', desc: 'Check in a guest', href: '/dashboard/app' },
            { icon: '🧹', label: 'Housekeeping', desc: 'Manage room status', href: '/dashboard/app' },
            { icon: '💳', label: 'Process Payment', desc: 'Collect from guest', href: '/dashboard/app' },
            { icon: '👥', label: 'Manage Staff', desc: 'Add or edit team', href: '/dashboard/settings' },
            { icon: '📊', label: 'View Reports', desc: 'Revenue & stats', href: '/dashboard/app' },
          ].map(a => (
            <Link key={a.label} href={a.href} style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '10px 12px', borderRadius: '8px', textDecoration: 'none', marginBottom: '4px', transition: 'background .15s' }}
              onMouseEnter={e => e.currentTarget.style.background = 'var(--bg3)'}
              onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
            >
              <span style={{ fontSize: '20px' }}>{a.icon}</span>
              <div>
                <div style={{ fontSize: '14px', fontWeight: 500, color: 'var(--white)' }}>{a.label}</div>
                <div style={{ fontSize: '12px', color: 'var(--silver)' }}>{a.desc}</div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
