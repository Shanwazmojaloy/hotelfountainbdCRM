'use client'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase'

const COLORS = ['#C8A96E', '#4A8CCA', '#3DBA8C', '#9B7DD4', '#D95F5F', '#E5A84A', '#5AB4D4', '#E87D4A']
const CURRENCIES = [{ code: 'BDT', symbol: '৳', name: 'Bangladeshi Taka' }, { code: 'USD', symbol: '$', name: 'US Dollar' }, { code: 'EUR', symbol: '€', name: 'Euro' }, { code: 'GBP', symbol: '£', name: 'British Pound' }, { code: 'INR', symbol: '₹', name: 'Indian Rupee' }, { code: 'AED', symbol: 'د.إ', name: 'UAE Dirham' }]
const TIMEZONES = ['Asia/Dhaka', 'Asia/Kolkata', 'Asia/Dubai', 'Europe/London', 'America/New_York', 'America/Los_Angeles', 'Asia/Singapore', 'Asia/Tokyo']

export default function OnboardingPage() {
  const router = useRouter()
  const [tenant, setTenant] = useState(null)
  const [color, setColor] = useState('#C8A96E')
  const [currency, setCurrency] = useState('BDT')
  const [timezone, setTimezone] = useState('Asia/Dhaka')
  const [customColor, setCustomColor] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const load = async () => {
      const sb = createClient()
      const { data: { user } } = await sb.auth.getUser()
      if (!user) { router.push('/auth/login'); return }
      const { data: t } = await sb.from('tenants').select('*').eq('owner_id', user.id).single()
      if (t) setTenant(t)
    }
    load()
  }, [])

  const save = async () => {
    setLoading(true)
    const sb = createClient()
    await sb.from('tenants').update({ primary_color: customColor || color, currency, timezone, onboarding_complete: true }).eq('id', tenant.id)
    router.push('/dashboard')
  }

  if (!tenant) return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--silver)' }}>
      Loading…
    </div>
  )

  const finalColor = customColor || color

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem' }}>
      <div style={{ width: '100%', maxWidth: '900px' }}>
        <div style={{ textAlign: 'center', marginBottom: '40px' }}>
          <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '40px', fontWeight: 400, marginBottom: '8px' }}>
            Set up <span style={{ color: 'var(--gold)', fontStyle: 'italic' }}>{tenant.hotel_name}</span>
          </h1>
          <p style={{ color: 'var(--silver)' }}>Customize your hotel's identity. You can change this anytime.</p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: '24px' }}>
          {/* Settings */}
          <div style={{ padding: '40px', background: 'var(--bg2)', borderRadius: '16px', border: '1px solid var(--border)' }}>
            <h3 style={{ fontWeight: 600, marginBottom: '24px', fontSize: '15px' }}>Brand Color</h3>
            <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', marginBottom: '16px' }}>
              {COLORS.map(c => (
                <button key={c} onClick={() => { setColor(c); setCustomColor('') }} style={{
                  width: '40px', height: '40px', borderRadius: '50%', background: c, border: `3px solid ${color === c && !customColor ? 'white' : 'transparent'}`, cursor: 'pointer', transition: 'transform .2s',
                }} />
              ))}
            </div>
            <div style={{ display: 'flex', gap: '12px', alignItems: 'center', marginBottom: '32px' }}>
              <input type="color" value={customColor || color} onChange={e => setCustomColor(e.target.value)}
                style={{ width: '48px', height: '40px', border: 'none', borderRadius: '8px', cursor: 'pointer', background: 'none' }} />
              <input value={customColor || color} onChange={e => setCustomColor(e.target.value)} placeholder="#C8A96E"
                style={{ flex: 1, padding: '10px 14px', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--white)', fontSize: '14px', outline: 'none', fontFamily: "'JetBrains Mono', monospace" }} />
            </div>

            <h3 style={{ fontWeight: 600, marginBottom: '16px', fontSize: '15px' }}>Currency</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '32px' }}>
              {CURRENCIES.map(c => (
                <button key={c.code} onClick={() => setCurrency(c.code)} style={{
                  padding: '10px 14px', background: currency === c.code ? `${finalColor}20` : 'var(--bg3)',
                  border: `1px solid ${currency === c.code ? finalColor : 'var(--border)'}`,
                  borderRadius: '8px', cursor: 'pointer', color: 'var(--white)', fontSize: '13px', textAlign: 'left',
                  transition: 'all .2s',
                }}>
                  <strong>{c.code}</strong> · {c.symbol} {c.name}
                </button>
              ))}
            </div>

            <h3 style={{ fontWeight: 600, marginBottom: '16px', fontSize: '15px' }}>Timezone</h3>
            <select value={timezone} onChange={e => setTimezone(e.target.value)} style={{ width: '100%', padding: '11px 14px', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--white)', fontSize: '14px', outline: 'none', marginBottom: '32px' }}>
              {TIMEZONES.map(tz => <option key={tz} value={tz}>{tz}</option>)}
            </select>

            <button onClick={save} disabled={loading} style={{ width: '100%', padding: '14px', background: finalColor, color: '#07090E', border: 'none', borderRadius: '8px', cursor: loading ? 'not-allowed' : 'pointer', fontWeight: 700, fontSize: '15px', opacity: loading ? 0.7 : 1 }}>
              {loading ? 'Launching your CRM…' : 'Launch my hotel CRM →'}
            </button>
          </div>

          {/* Live Preview */}
          <div style={{ padding: '32px', background: 'var(--bg2)', borderRadius: '16px', border: '1px solid var(--border)' }}>
            <div style={{ fontSize: '12px', color: 'var(--silver)', marginBottom: '16px', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 600 }}>Live Preview</div>
            {/* Mini CRM preview */}
            <div style={{ background: 'var(--bg)', borderRadius: '12px', overflow: 'hidden', border: '1px solid var(--border2)' }}>
              {/* Sidebar */}
              <div style={{ display: 'flex', height: '360px' }}>
                <div style={{ width: '120px', background: '#0D1117', padding: '16px 12px', borderRight: '1px solid var(--border2)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '20px' }}>
                    <div style={{ width: '24px', height: '24px', borderRadius: '6px', background: finalColor }} />
                    <span style={{ fontSize: '11px', fontWeight: 700, color: finalColor, lineHeight: 1.2, maxWidth: '70px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{tenant.hotel_name}</span>
                  </div>
                  {['Dashboard', 'Rooms', 'Guests', 'Bookings', 'Billing'].map((m, i) => (
                    <div key={m} style={{ padding: '6px 8px', borderRadius: '6px', fontSize: '11px', marginBottom: '4px', background: i === 0 ? `${finalColor}25` : 'transparent', color: i === 0 ? finalColor : 'var(--silver)', fontWeight: i === 0 ? 600 : 400 }}>{m}</div>
                  ))}
                </div>
                {/* Main */}
                <div style={{ flex: 1, padding: '16px', overflow: 'hidden' }}>
                  <div style={{ fontSize: '14px', fontWeight: 600, marginBottom: '12px' }}>Dashboard</div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '12px' }}>
                    {[['Occupancy', '78%', finalColor], ['Revenue', '৳82k', 'var(--success)'], ['Check-ins', '12', 'var(--gold)'], ['Guests', '34', '#9B7DD4']].map(([l, v, c]) => (
                      <div key={l} style={{ padding: '10px', background: 'var(--bg2)', borderRadius: '8px', border: '1px solid var(--border2)' }}>
                        <div style={{ fontSize: '10px', color: 'var(--silver)', marginBottom: '4px' }}>{l}</div>
                        <div style={{ fontSize: '16px', fontWeight: 700, color: c }}>{v}</div>
                      </div>
                    ))}
                  </div>
                  <div style={{ background: 'var(--bg2)', borderRadius: '8px', padding: '10px', border: '1px solid var(--border2)' }}>
                    <div style={{ fontSize: '10px', color: 'var(--silver)', marginBottom: '8px' }}>Recent Reservations</div>
                    {[['101', 'Ahmed R.', finalColor], ['205', 'Priya S.', 'var(--silver)'], ['312', 'Carlos M.', 'var(--silver)']].map(([r, n, c]) => (
                      <div key={r} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10px', padding: '3px 0', borderBottom: '1px solid var(--border2)', color: c }}>
                        <span>Rm {r} · {n}</span><span style={{ color: 'var(--success)' }}>Active</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            <p style={{ fontSize: '12px', color: 'var(--silver)', textAlign: 'center', marginTop: '12px' }}>Your branded CRM preview</p>
          </div>
        </div>
      </div>
    </div>
  )
}
