'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase'

export default function LoginPage() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const login = async (e) => {
    e.preventDefault()
    setLoading(true); setError('')
    const sb = createClient()
    const { error: err } = await sb.auth.signInWithPassword({ email, password })
    if (err) { setError(err.message); setLoading(false); return }
    // Check if tenant exists
    const { data: tu } = await sb.from('tenant_users').select('tenant_id').eq('user_id', (await sb.auth.getUser()).data.user.id).single()
    if (tu?.tenant_id) {
      // Check onboarding
      const { data: tenant } = await sb.from('tenants').select('onboarding_complete').eq('id', tu.tenant_id).single()
      if (!tenant?.onboarding_complete) router.push('/auth/onboarding')
      else router.push('/dashboard')
    } else {
      const { data: tenant } = await sb.from('tenants').select('id,onboarding_complete').eq('owner_id', (await sb.auth.getUser()).data.user.id).single()
      if (!tenant) router.push('/auth/signup')
      else if (!tenant.onboarding_complete) router.push('/auth/onboarding')
      else router.push('/dashboard')
    }
  }

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'var(--bg)',
      backgroundImage: 'radial-gradient(ellipse 60% 50% at 50% 0%, rgba(200,169,110,0.08) 0%, transparent 70%)',
    }}>
      <div style={{ width: '100%', maxWidth: '420px', padding: '2rem' }}>
        <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: '8px', textDecoration: 'none', marginBottom: '48px', justifyContent: 'center' }}>
          <span style={{ fontSize: '24px' }}>🏨</span>
          <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '24px', color: 'var(--gold)', fontWeight: 600 }}>HotelOS</span>
        </Link>
        <div style={{ padding: '40px', background: 'var(--bg2)', borderRadius: '16px', border: '1px solid var(--border)' }}>
          <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '28px', fontWeight: 500, marginBottom: '8px' }}>Welcome back</h1>
          <p style={{ color: 'var(--silver)', fontSize: '14px', marginBottom: '32px' }}>Sign in to your hotel dashboard</p>

          {error && (
            <div style={{ padding: '12px', background: 'rgba(217,95,95,0.1)', border: '1px solid var(--danger)', borderRadius: '8px', color: 'var(--danger)', fontSize: '14px', marginBottom: '20px' }}>
              {error}
            </div>
          )}

          <form onSubmit={login}>
            <div style={{ marginBottom: '16px' }}>
              <label style={{ display: 'block', fontSize: '13px', color: 'var(--silver)', marginBottom: '6px', fontWeight: 500 }}>Email</label>
              <input value={email} onChange={e => setEmail(e.target.value)} type="email" required placeholder="you@hotel.com"
                style={{ width: '100%', padding: '11px 14px', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--white)', fontSize: '14px', outline: 'none', boxSizing: 'border-box' }} />
            </div>
            <div style={{ marginBottom: '24px' }}>
              <label style={{ display: 'block', fontSize: '13px', color: 'var(--silver)', marginBottom: '6px', fontWeight: 500 }}>Password</label>
              <input value={password} onChange={e => setPassword(e.target.value)} type="password" required placeholder="••••••••"
                style={{ width: '100%', padding: '11px 14px', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--white)', fontSize: '14px', outline: 'none', boxSizing: 'border-box' }} />
            </div>
            <button type="submit" disabled={loading} style={{
              width: '100%', padding: '13px', background: loading ? 'rgba(200,169,110,0.5)' : 'var(--gold)',
              color: '#07090E', border: 'none', borderRadius: '8px', cursor: loading ? 'not-allowed' : 'pointer',
              fontSize: '15px', fontWeight: 700,
            }}>
              {loading ? 'Signing in…' : 'Sign in →'}
            </button>
          </form>

          <p style={{ textAlign: 'center', marginTop: '24px', fontSize: '14px', color: 'var(--silver)' }}>
            No account?{' '}
            <Link href="/auth/signup" style={{ color: 'var(--gold)', textDecoration: 'none' }}>Start free trial</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
