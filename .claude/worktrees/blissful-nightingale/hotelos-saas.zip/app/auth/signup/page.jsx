'use client'
import { useState, Suspense } from 'react'
import Link from 'next/link'
import { useRouter, useSearchParams } from 'next/navigation'
import { createClient } from '@/lib/supabase'
import { PLANS } from '@/lib/plans'

function SignupForm() {
  const router = useRouter()
  const params = useSearchParams()
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [form, setForm] = useState({
    name: '', email: '', password: '',
    hotelName: '', hotelSlug: '',
    plan: params.get('plan') || 'pro',
  })

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))

  const slugify = (str) => str.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')

  const submit = async () => {
    setLoading(true); setError('')
    const sb = createClient()
    // 1. Create auth user
    const { data: authData, error: authErr } = await sb.auth.signUp({ email: form.email, password: form.password, options: { data: { name: form.name } } })
    if (authErr) { setError(authErr.message); setLoading(false); return }
    const userId = authData.user.id

    // 2. Create tenant
    const { data: tenant, error: tErr } = await sb.from('tenants').insert({
      owner_id: userId, hotel_name: form.hotelName, hotel_slug: form.hotelSlug,
      primary_color: '#C8A96E', onboarding_complete: false,
    }).select().single()
    if (tErr) { setError(tErr.message); setLoading(false); return }

    // 3. Create tenant_user
    await sb.from('tenant_users').insert({ tenant_id: tenant.id, user_id: userId, role: 'owner', name: form.name, email: form.email, is_owner: true })

    // 4. Create subscription (trial)
    await sb.from('subscriptions').insert({ tenant_id: tenant.id, plan: form.plan, status: 'trialing' })

    // 5. Seed sample rooms
    const rooms = []
    for (let i = 1; i <= 10; i++) {
      rooms.push({ tenant_id: tenant.id, room_number: `10${i}`, floor: 1, type: i <= 3 ? 'deluxe' : i <= 6 ? 'standard' : 'suite', beds: i <= 6 ? 2 : 1, rate: i <= 3 ? 4500 : i <= 6 ? 3000 : 7500, status: 'available' })
    }
    await sb.from('tenant_rooms').insert(rooms)

    router.push('/auth/onboarding')
  }

  const nextStep = async () => {
    if (step === 1) {
      if (!form.name || !form.email || !form.password) { setError('Please fill all fields'); return }
      if (form.password.length < 6) { setError('Password must be at least 6 characters'); return }
      setError(''); setStep(2)
    } else if (step === 2) {
      if (!form.hotelName) { setError('Enter your hotel name'); return }
      if (!form.hotelSlug) set('hotelSlug', slugify(form.hotelName))
      // Check slug uniqueness
      const sb = createClient()
      const { data } = await sb.from('tenants').select('id').eq('hotel_slug', form.hotelSlug || slugify(form.hotelName)).single()
      if (data) { setError('That slug is taken. Try another.'); return }
      setError(''); setStep(3)
    }
  }

  const PLAN_LIST = Object.values(PLANS)

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg)', backgroundImage: 'radial-gradient(ellipse 60% 50% at 50% 0%, rgba(200,169,110,0.08) 0%, transparent 70%)' }}>
      <div style={{ width: '100%', maxWidth: step === 3 ? '900px' : '460px', padding: '2rem' }}>
        <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: '8px', textDecoration: 'none', marginBottom: '32px', justifyContent: 'center' }}>
          <span>🏨</span>
          <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '22px', color: 'var(--gold)' }}>HotelOS</span>
        </Link>

        {/* Steps */}
        <div style={{ display: 'flex', gap: '8px', marginBottom: '32px', justifyContent: 'center' }}>
          {['Account', 'Your Hotel', 'Choose Plan'].map((s, i) => (
            <div key={s} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <div style={{
                width: '28px', height: '28px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: step > i + 1 ? 'var(--success)' : step === i + 1 ? 'var(--gold)' : 'var(--bg3)',
                color: step >= i + 1 ? '#07090E' : 'var(--silver)', fontSize: '13px', fontWeight: 700,
              }}>{step > i + 1 ? '✓' : i + 1}</div>
              <span style={{ fontSize: '13px', color: step === i + 1 ? 'var(--white)' : 'var(--silver)' }}>{s}</span>
              {i < 2 && <div style={{ width: '32px', height: '1px', background: step > i + 1 ? 'var(--success)' : 'var(--border)' }} />}
            </div>
          ))}
        </div>

        <div style={{ padding: '40px', background: 'var(--bg2)', borderRadius: '16px', border: '1px solid var(--border)' }}>
          {error && <div style={{ padding: '12px', background: 'rgba(217,95,95,0.1)', border: '1px solid var(--danger)', borderRadius: '8px', color: 'var(--danger)', fontSize: '14px', marginBottom: '20px' }}>{error}</div>}

          {step === 1 && (
            <>
              <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '28px', marginBottom: '24px' }}>Create your account</h2>
              {[['name', 'Full name', 'text', 'Jane Smith'], ['email', 'Work email', 'email', 'jane@hotel.com'], ['password', 'Password', 'password', '8+ characters']].map(([k, label, type, ph]) => (
                <div key={k} style={{ marginBottom: '16px' }}>
                  <label style={{ display: 'block', fontSize: '13px', color: 'var(--silver)', marginBottom: '6px', fontWeight: 500 }}>{label}</label>
                  <input value={form[k]} onChange={e => set(k, e.target.value)} type={type} placeholder={ph} style={{ width: '100%', padding: '11px 14px', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--white)', fontSize: '14px', outline: 'none', boxSizing: 'border-box' }} />
                </div>
              ))}
              <button onClick={nextStep} style={{ width: '100%', padding: '13px', background: 'var(--gold)', color: '#07090E', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 700, fontSize: '15px', marginTop: '8px' }}>
                Continue →
              </button>
              <p style={{ textAlign: 'center', marginTop: '20px', fontSize: '13px', color: 'var(--silver)' }}>
                Already have an account?{' '}<Link href="/auth/login" style={{ color: 'var(--gold)', textDecoration: 'none' }}>Sign in</Link>
              </p>
            </>
          )}

          {step === 2 && (
            <>
              <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '28px', marginBottom: '8px' }}>Your hotel</h2>
              <p style={{ color: 'var(--silver)', fontSize: '14px', marginBottom: '24px' }}>This becomes your white-labeled CRM identity.</p>
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', fontSize: '13px', color: 'var(--silver)', marginBottom: '6px', fontWeight: 500 }}>Hotel name</label>
                <input value={form.hotelName} onChange={e => { set('hotelName', e.target.value); set('hotelSlug', slugify(e.target.value)) }} placeholder="The Grand Palace Hotel"
                  style={{ width: '100%', padding: '11px 14px', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--white)', fontSize: '14px', outline: 'none', boxSizing: 'border-box' }} />
              </div>
              <div style={{ marginBottom: '24px' }}>
                <label style={{ display: 'block', fontSize: '13px', color: 'var(--silver)', marginBottom: '6px', fontWeight: 500 }}>URL slug</label>
                <div style={{ display: 'flex', alignItems: 'center', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '8px', overflow: 'hidden' }}>
                  <span style={{ padding: '11px 12px', color: 'var(--silver)', fontSize: '13px', borderRight: '1px solid var(--border)', whiteSpace: 'nowrap' }}>hotelos.app/</span>
                  <input value={form.hotelSlug} onChange={e => set('hotelSlug', slugify(e.target.value))} placeholder="grand-palace"
                    style={{ flex: 1, padding: '11px 14px', background: 'transparent', border: 'none', color: 'var(--white)', fontSize: '14px', outline: 'none' }} />
                </div>
              </div>
              <div style={{ display: 'flex', gap: '12px' }}>
                <button onClick={() => setStep(1)} style={{ flex: 1, padding: '13px', background: 'transparent', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--white)', cursor: 'pointer', fontWeight: 600 }}>← Back</button>
                <button onClick={nextStep} style={{ flex: 2, padding: '13px', background: 'var(--gold)', color: '#07090E', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 700 }}>Choose plan →</button>
              </div>
            </>
          )}

          {step === 3 && (
            <>
              <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '28px', marginBottom: '8px' }}>Choose a plan</h2>
              <p style={{ color: 'var(--silver)', fontSize: '14px', marginBottom: '28px' }}>All plans include a 14-day free trial.</p>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '16px', marginBottom: '24px' }}>
                {PLAN_LIST.map(p => (
                  <div key={p.id} onClick={() => set('plan', p.id)} style={{
                    padding: '24px', borderRadius: '12px', cursor: 'pointer', transition: 'all .2s',
                    border: `2px solid ${form.plan === p.id ? p.color : 'var(--border)'}`,
                    background: form.plan === p.id ? `${p.color}12` : 'var(--bg3)',
                  }}>
                    {p.highlight && <div style={{ fontSize: '11px', fontWeight: 700, color: p.color, marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.1em' }}>★ Popular</div>}
                    <div style={{ fontWeight: 700, fontSize: '16px', marginBottom: '4px' }}>{p.name}</div>
                    <div style={{ fontSize: '24px', fontWeight: 700, color: p.color, marginBottom: '12px' }}>${p.price}<span style={{ fontSize: '13px', color: 'var(--silver)', fontWeight: 400 }}>/mo</span></div>
                    <div style={{ fontSize: '13px', color: 'var(--silver)' }}>{p.tagline}</div>
                  </div>
                ))}
              </div>
              <div style={{ display: 'flex', gap: '12px' }}>
                <button onClick={() => setStep(2)} style={{ flex: 1, padding: '13px', background: 'transparent', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--white)', cursor: 'pointer', fontWeight: 600 }}>← Back</button>
                <button onClick={submit} disabled={loading} style={{ flex: 2, padding: '13px', background: loading ? 'rgba(200,169,110,0.5)' : 'var(--gold)', color: '#07090E', border: 'none', borderRadius: '8px', cursor: loading ? 'not-allowed' : 'pointer', fontWeight: 700 }}>
                  {loading ? 'Creating your hotel…' : 'Start free trial →'}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

export default function SignupPage() {
  return <Suspense fallback={<div style={{display:'flex',alignItems:'center',justifyContent:'center',minHeight:'100vh',background:'var(--bg)',color:'var(--silver)'}}>Loading…</div>}><SignupForm /></Suspense>
}
