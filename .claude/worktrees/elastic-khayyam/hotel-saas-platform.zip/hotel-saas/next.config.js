/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['mynwfkgksqqwlqowlscj.supabase.co'],
  },
}
module.exports = nextConfig
