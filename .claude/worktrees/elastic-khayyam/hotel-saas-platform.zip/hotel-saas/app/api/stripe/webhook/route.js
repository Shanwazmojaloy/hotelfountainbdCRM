import { createClient } from '@supabase/supabase-js'
import Stripe from 'stripe'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY)

// Use service role for webhook (bypasses RLS)
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

export async function POST(req) {
  const body = await req.text()
  const sig = req.headers.get('stripe-signature')

  let event
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET)
  } catch (err) {
    return Response.json({ error: 'Invalid signature' }, { status: 400 })
  }

  const tenantId = event.data.object.metadata?.tenant_id

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object
      if (session.subscription) {
        const stripeSub = await stripe.subscriptions.retrieve(session.subscription)
        await supabase.from('subscriptions').update({
          status: 'active',
          stripe_subscription_id: stripeSub.id,
          stripe_price_id: stripeSub.items.data[0].price.id,
          current_period_start: new Date(stripeSub.current_period_start * 1000).toISOString(),
          current_period_end: new Date(stripeSub.current_period_end * 1000).toISOString(),
          updated_at: new Date().toISOString(),
        }).eq('tenant_id', tenantId)
      }
      break
    }

    case 'invoice.payment_succeeded': {
      const invoice = event.data.object
      const stripeSub = await stripe.subscriptions.retrieve(invoice.subscription)
      await supabase.from('subscriptions').update({
        status: 'active',
        current_period_start: new Date(stripeSub.current_period_start * 1000).toISOString(),
        current_period_end: new Date(stripeSub.current_period_end * 1000).toISOString(),
        updated_at: new Date().toISOString(),
      }).eq('stripe_subscription_id', invoice.subscription)
      break
    }

    case 'invoice.payment_failed': {
      await supabase.from('subscriptions').update({
        status: 'past_due', updated_at: new Date().toISOString(),
      }).eq('stripe_subscription_id', event.data.object.subscription)
      break
    }

    case 'customer.subscription.deleted': {
      await supabase.from('subscriptions').update({
        status: 'canceled', updated_at: new Date().toISOString(),
      }).eq('stripe_subscription_id', event.data.object.id)
      break
    }

    case 'customer.subscription.updated': {
      const stripeSub = event.data.object
      const priceId = stripeSub.items.data[0].price.id
      // Determine plan from price ID
      const PRICE_MAP = {
        [process.env.NEXT_PUBLIC_STRIPE_STARTER_PRICE_ID]: 'starter',
        [process.env.NEXT_PUBLIC_STRIPE_PRO_PRICE_ID]: 'pro',
        [process.env.NEXT_PUBLIC_STRIPE_ENTERPRISE_PRICE_ID]: 'enterprise',
      }
      await supabase.from('subscriptions').update({
        status: stripeSub.status,
        plan: PRICE_MAP[priceId] || 'pro',
        cancel_at_period_end: stripeSub.cancel_at_period_end,
        updated_at: new Date().toISOString(),
      }).eq('stripe_subscription_id', stripeSub.id)
      break
    }
  }

  return Response.json({ received: true })
}
