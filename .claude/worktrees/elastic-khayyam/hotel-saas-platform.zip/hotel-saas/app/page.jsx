'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { PLANS } from '../lib/plans'

const FEATURES = [
  { icon: '🏨', title: 'Room Management', desc: 'Real-time room status, housekeeping sync, and dynamic pricing in one view.' },
  { icon: '📋', title: 'Reservations', desc: 'Drag-to-book calendar, group bookings, OTA sync, and automated confirmations.' },
  { icon: '👥', title: 'Guest CRM', desc: 'Full guest profiles, VIP tracking, preferences, and stay history.' },
  { icon: '💳', title: 'Billing & Invoicing', desc: 'Multi-currency invoices, split bills, VAT/tax automation, and payment tracking.' },
  { icon: '🧹', title: 'Housekeeping', desc: 'Task assignment, room priority queues, and real-time status updates for staff.' },
  { icon: '📊', title: 'Reports & Analytics', desc: 'RevPAR, ADR, occupancy trends, and downloadable closing reports.' },
  { icon: '🎨', title: 'Custom Branding', desc: 'Your hotel name, logo, and colors. White-label with no HotelOS branding.' },
  { icon: '🔐', title: 'Role-Based Access', desc: 'Superadmin, manager, receptionist, housekeeping, accountant — all separate.' },
]

const TESTIMONIALS = [
  { name: 'Rafiq Hossain', role: 'Owner, Hotel Gulshan Palace', text: 'We went from spreadsheets to a fully branded CRM in one afternoon. Our front desk loves it.', avatar: 'R' },
  { name: 'Priya Sharma', role: 'GM, The Meridian Suites', text: 'The occupancy reports alone saved us hours every week. Worth every penny.', avatar: 'P' },
  { name: 'Ahmed Al-Rashid', role: 'Director, Al-Noor Hotel Group', text: 'We manage 3 properties with different branding on one account. No other platform offers this.', avatar: 'A' },
]

export default function LandingPage() {
  const [scrolled, setScrolled] = useState(false)
  const [billingCycle, setBillingCycle] = useState('monthly')
  const [openFaq, setOpenFaq] = useState(null)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const price = (p) => billingCycle === 'yearly' ? Math.round(p * 0.8) : p

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>

      {/* NAV */}
      <nav style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
        padding: '0 2rem',
        background: scrolled ? 'rgba(8,11,16,0.95)' : 'transparent',
        backdropFilter: scrolled ? 'blur(20px)' : 'none',
        borderBottom: scrolled ? '1px solid var(--border2)' : '1px solid transparent',
        transition: 'all 0.3s ease',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        height: '68px',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
          <div style={{
            width: 32, height: 32, borderRadius: 8,
            background: 'linear-gradient(135deg, var(--gold), var(--gold2))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 16,
          }}>🏨</div>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: '1.2rem', color: 'var(--gold)' }}>HotelOS</span>
        </div>

        <div style={{ display: 'flex', gap: '2rem', alignItems: 'center' }}>
          {['Features', 'Pricing', 'FAQ'].map(item => (
            <a key={item} href={`#${item.toLowerCase()}`} style={{
              color: 'var(--silver)', fontSize: '0.875rem', textDecoration: 'none',
              transition: 'color 0.2s',
            }}
              onMouseEnter={e => e.target.style.color = 'var(--white)'}
              onMouseLeave={e => e.target.style.color = 'var(--silver)'}
            >{item}</a>
          ))}
          <Link href="/auth/login" style={{
            color: 'var(--silver)', fontSize: '0.875rem', textDecoration: 'none',
          }}>Sign in</Link>
          <Link href="/auth/signup" style={{
            background: 'linear-gradient(135deg, var(--gold), var(--gold2))',
            color: '#080B10', padding: '0.5rem 1.25rem', borderRadius: 8,
            fontSize: '0.875rem', fontWeight: 500, textDecoration: 'none',
            transition: 'opacity 0.2s',
          }}>Start free trial</Link>
        </div>
      </nav>

      {/* HERO */}
      <section style={{
        minHeight: '100vh', display: 'flex', alignItems: 'center',
        justifyContent: 'center', textAlign: 'center',
        padding: '8rem 2rem 4rem',
        position: 'relative', overflow: 'hidden',
      }}>
        {/* Ambient bg */}
        <div style={{
          position: 'absolute', inset: 0, zIndex: 0,
          background: `
            radial-gradient(ellipse 80% 60% at 50% 0%, rgba(200,169,110,0.12) 0%, transparent 70%),
            radial-gradient(ellipse 40% 40% at 20% 80%, rgba(200,169,110,0.06) 0%, transparent 60%),
            radial-gradient(ellipse 40% 40% at 80% 80%, rgba(78,203,163,0.04) 0%, transparent 60%)
          `,
        }} />

        {/* Grid lines */}
        <div style={{
          position: 'absolute', inset: 0, zIndex: 0,
          backgroundImage: `
            linear-gradient(rgba(200,169,110,0.04) 1px, transparent 1px),
            linear-gradient(90deg, rgba(200,169,110,0.04) 1px, transparent 1px)
          `,
          backgroundSize: '60px 60px',
        }} />

        <div style={{ position: 'relative', zIndex: 1, maxWidth: 860, animation: 'fadeUp 0.8s ease both' }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
            background: 'rgba(200,169,110,0.1)', border: '1px solid var(--border)',
            borderRadius: 100, padding: '0.4rem 1rem', marginBottom: '2rem',
            fontSize: '0.8rem', color: 'var(--gold)',
          }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--success)', animation: 'shimmer 2s ease infinite' }} />
            14-day free trial — no credit card required
          </div>

          <h1 style={{
            fontFamily: 'var(--font-display)', fontSize: 'clamp(2.5rem, 7vw, 5.5rem)',
            lineHeight: 1.1, marginBottom: '1.5rem',
            background: 'linear-gradient(135deg, var(--white) 0%, var(--gold2) 60%, var(--gold) 100%)',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          }}>
            Your Hotel,<br />
            <em>Your Brand.</em><br />
            <span style={{ fontSize: '0.7em' }}>Fully Managed.</span>
          </h1>

          <p style={{
            fontSize: 'clamp(1rem, 2vw, 1.25rem)', color: 'var(--silver)',
            maxWidth: 560, margin: '0 auto 2.5rem', lineHeight: 1.7,
          }}>
            Launch a complete hotel management CRM with your logo, colors, and domain — in minutes. Reservations, billing, housekeeping, analytics, and more.
          </p>

          <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link href="/auth/signup" style={{
              background: 'linear-gradient(135deg, var(--gold), var(--gold2))',
              color: '#080B10', padding: '1rem 2.5rem', borderRadius: 12,
              fontSize: '1rem', fontWeight: 600, textDecoration: 'none',
              boxShadow: '0 8px 32px rgba(200,169,110,0.3)',
              transition: 'all 0.2s',
            }}>
              Start free trial →
            </Link>
            <a href="#features" style={{
              background: 'rgba(255,255,255,0.06)', border: '1px solid var(--border)',
              color: 'var(--white)', padding: '1rem 2rem', borderRadius: 12,
              fontSize: '1rem', textDecoration: 'none',
              transition: 'all 0.2s',
            }}>
              See features
            </a>
          </div>

          {/* Social proof */}
          <div style={{
            marginTop: '4rem', display: 'flex', justifyContent: 'center',
            gap: '3rem', flexWrap: 'wrap',
          }}>
            {[['500+', 'Hotels active'], ['99.9%', 'Uptime SLA'], ['14-day', 'Free trial'], ['24/7', 'Support']].map(([val, label]) => (
              <div key={label} style={{ textAlign: 'center' }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', color: 'var(--gold)' }}>{val}</div>
                <div style={{ fontSize: '0.8rem', color: 'var(--silver)' }}>{label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" style={{ padding: '6rem 2rem', maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '4rem', animation: 'fadeUp 0.6s ease both' }}>
          <p style={{ fontSize: '0.8rem', color: 'var(--gold)', letterSpacing: '0.2em', textTransform: 'uppercase', marginBottom: '1rem' }}>Everything you need</p>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(2rem, 4vw, 3rem)', marginBottom: '1rem' }}>
            A complete hotel OS,<br /><em>beautifully branded</em>
          </h2>
          <p style={{ color: 'var(--silver)', maxWidth: 500, margin: '0 auto' }}>
            Every module your hotel needs, white-labeled with your identity. No "Powered by" watermarks.
          </p>
        </div>

        <div style={{
          display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: '1.5rem',
        }}>
          {FEATURES.map((f, i) => (
            <div key={f.title} style={{
              background: 'var(--bg2)', border: '1px solid var(--border2)',
              borderRadius: 16, padding: '1.75rem',
              animation: `fadeUp 0.6s ease ${i * 0.07}s both`,
              transition: 'all 0.3s ease',
              cursor: 'default',
            }}
              onMouseEnter={e => {
                e.currentTarget.style.borderColor = 'rgba(200,169,110,0.3)'
                e.currentTarget.style.transform = 'translateY(-4px)'
                e.currentTarget.style.boxShadow = '0 12px 40px rgba(200,169,110,0.08)'
              }}
              onMouseLeave={e => {
                e.currentTarget.style.borderColor = 'var(--border2)'
                e.currentTarget.style.transform = 'translateY(0)'
                e.currentTarget.style.boxShadow = 'none'
              }}
            >
              <div style={{ fontSize: '2rem', marginBottom: '1rem' }}>{f.icon}</div>
              <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.15rem', marginBottom: '0.5rem' }}>{f.title}</h3>
              <p style={{ color: 'var(--silver)', fontSize: '0.875rem', lineHeight: 1.6 }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section style={{
        padding: '6rem 2rem',
        background: 'linear-gradient(180deg, transparent 0%, rgba(200,169,110,0.04) 50%, transparent 100%)',
      }}>
        <div style={{ maxWidth: 900, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '4rem' }}>
            <p style={{ fontSize: '0.8rem', color: 'var(--gold)', letterSpacing: '0.2em', textTransform: 'uppercase', marginBottom: '1rem' }}>Get started in minutes</p>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(2rem, 4vw, 3rem)' }}>How it works</h2>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '2rem' }}>
            {[
              { step: '01', title: 'Sign up', desc: 'Create your account and choose a plan. 14-day trial, no card needed.' },
              { step: '02', title: 'Brand it', desc: 'Enter your hotel name, upload logo, set your colors and domain.' },
              { step: '03', title: 'Add your team', desc: 'Invite staff with role-based access — front desk, housekeeping, accounting.' },
              { step: '04', title: 'Go live', desc: 'Your hotel CRM is ready. Start managing reservations from day one.' },
            ].map((item, i) => (
              <div key={item.step} style={{ textAlign: 'center', padding: '1.5rem' }}>
                <div style={{
                  fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--gold)',
                  marginBottom: '1rem', opacity: 0.7,
                }}>{item.step}</div>
                <div style={{
                  width: 56, height: 56, borderRadius: '50%',
                  border: '1px solid var(--border)', margin: '0 auto 1rem',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: '1.5rem', background: 'var(--bg2)',
                }}>
                  {['✍️', '🎨', '👥', '🚀'][i]}
                </div>
                <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', marginBottom: '0.5rem' }}>{item.title}</h3>
                <p style={{ color: 'var(--silver)', fontSize: '0.875rem', lineHeight: 1.6 }}>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" style={{ padding: '6rem 2rem', maxWidth: 1100, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <p style={{ fontSize: '0.8rem', color: 'var(--gold)', letterSpacing: '0.2em', textTransform: 'uppercase', marginBottom: '1rem' }}>Simple pricing</p>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(2rem, 4vw, 3rem)', marginBottom: '2rem' }}>
            Choose your plan
          </h2>

          {/* Billing toggle */}
          <div style={{
            display: 'inline-flex', background: 'var(--bg2)', border: '1px solid var(--border2)',
            borderRadius: 100, padding: '4px',
          }}>
            {['monthly', 'yearly'].map(cycle => (
              <button key={cycle} onClick={() => setBillingCycle(cycle)} style={{
                padding: '0.5rem 1.5rem', borderRadius: 100, border: 'none',
                background: billingCycle === cycle ? 'var(--gold)' : 'transparent',
                color: billingCycle === cycle ? '#080B10' : 'var(--silver)',
                cursor: 'pointer', fontSize: '0.875rem', fontWeight: 500,
                transition: 'all 0.2s',
              }}>
                {cycle === 'yearly' ? 'Yearly (save 20%)' : 'Monthly'}
              </button>
            ))}
          </div>
        </div>

        <div style={{
          display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.5rem',
          alignItems: 'start',
        }}>
          {Object.values(PLANS).map((plan) => (
            <div key={plan.id} style={{
              background: plan.highlight ? 'linear-gradient(135deg, rgba(200,169,110,0.12), rgba(200,169,110,0.06))' : 'var(--bg2)',
              border: `1px solid ${plan.highlight ? 'rgba(200,169,110,0.4)' : 'var(--border2)'}`,
              borderRadius: 20, padding: '2rem',
              position: 'relative',
              transform: plan.highlight ? 'scale(1.03)' : 'scale(1)',
              boxShadow: plan.highlight ? '0 20px 60px rgba(200,169,110,0.15)' : 'none',
            }}>
              {plan.highlight && (
                <div style={{
                  position: 'absolute', top: -14, left: '50%', transform: 'translateX(-50%)',
                  background: 'linear-gradient(135deg, var(--gold), var(--gold2))',
                  color: '#080B10', fontSize: '0.7rem', fontWeight: 700,
                  padding: '4px 16px', borderRadius: 100, letterSpacing: '0.1em',
                  textTransform: 'uppercase',
                }}>Most Popular</div>
              )}

              <div style={{ marginBottom: '1.5rem' }}>
                <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', marginBottom: '0.25rem' }}>{plan.name}</h3>
                <p style={{ color: 'var(--silver)', fontSize: '0.875rem' }}>{plan.tagline}</p>
              </div>

              <div style={{ marginBottom: '2rem' }}>
                <span style={{ fontFamily: 'var(--font-display)', fontSize: '3rem', color: 'var(--gold)' }}>
                  ${price(plan.price)}
                </span>
                <span style={{ color: 'var(--silver)', fontSize: '0.875rem' }}>/month</span>
                {billingCycle === 'yearly' && (
                  <div style={{ fontSize: '0.75rem', color: 'var(--success)', marginTop: '0.25rem' }}>
                    Save ${(plan.price - price(plan.price)) * 12}/year
                  </div>
                )}
              </div>

              <ul style={{ listStyle: 'none', marginBottom: '2rem', display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {plan.features.map(f => (
                  <li key={f} style={{ display: 'flex', gap: '0.75rem', alignItems: 'flex-start', fontSize: '0.875rem' }}>
                    <span style={{ color: 'var(--gold)', flexShrink: 0, marginTop: '2px' }}>✓</span>
                    <span style={{ color: 'var(--silver)' }}>{f}</span>
                  </li>
                ))}
              </ul>

              <Link href={`/auth/signup?plan=${plan.id}`} style={{
                display: 'block', textAlign: 'center', padding: '0.875rem',
                borderRadius: 10, textDecoration: 'none', fontWeight: 500,
                background: plan.highlight
                  ? 'linear-gradient(135deg, var(--gold), var(--gold2))'
                  : 'rgba(255,255,255,0.06)',
                color: plan.highlight ? '#080B10' : 'var(--white)',
                border: plan.highlight ? 'none' : '1px solid var(--border)',
                transition: 'all 0.2s',
              }}>
                Start 14-day free trial
              </Link>
            </div>
          ))}
        </div>

        <p style={{ textAlign: 'center', color: 'var(--silver)', fontSize: '0.8rem', marginTop: '2rem' }}>
          All plans include 14-day free trial. No credit card required to start.
        </p>
      </section>

      {/* TESTIMONIALS */}
      <section style={{
        padding: '6rem 2rem',
        background: 'linear-gradient(180deg, transparent 0%, rgba(200,169,110,0.03) 50%, transparent 100%)',
      }}>
        <div style={{ maxWidth: 1000, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(2rem, 4vw, 3rem)' }}>
              Trusted by hoteliers
            </h2>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.5rem' }}>
            {TESTIMONIALS.map((t) => (
              <div key={t.name} style={{
                background: 'var(--bg2)', border: '1px solid var(--border2)',
                borderRadius: 16, padding: '1.75rem',
              }}>
                <div style={{ fontSize: '1.5rem', color: 'var(--gold)', marginBottom: '1rem' }}>"</div>
                <p style={{ color: 'var(--silver)', fontSize: '0.9rem', lineHeight: 1.7, marginBottom: '1.5rem' }}>{t.text}</p>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                  <div style={{
                    width: 40, height: 40, borderRadius: '50%',
                    background: 'linear-gradient(135deg, var(--gold), var(--gold2))',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    color: '#080B10', fontWeight: 700, fontSize: '0.9rem',
                  }}>{t.avatar}</div>
                  <div>
                    <div style={{ fontSize: '0.875rem', fontWeight: 500 }}>{t.name}</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--silver)' }}>{t.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" style={{ padding: '6rem 2rem', maxWidth: 700, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(2rem, 4vw, 3rem)' }}>
            Frequently asked
          </h2>
        </div>

        {[
          { q: 'Do guests or staff see "HotelOS" anywhere?', a: 'No. With Pro and Enterprise plans, HotelOS branding is completely removed. Your staff and guests only see your hotel name and logo.' },
          { q: 'Can I use my own domain?', a: 'Yes — Pro and Enterprise plans support custom domains. You can host your CRM at app.yourhotel.com with full SSL.' },
          { q: 'How does the free trial work?', a: '14 days, no credit card required. You get full access to your chosen plan. At the end of the trial, you can subscribe via Stripe or cancel with no charges.' },
          { q: 'Can I invite my staff?', a: 'Yes. Each plan includes staff accounts with role-based access. Starter gets 3, Pro gets 15, Enterprise is unlimited.' },
          { q: 'What happens to my data if I cancel?', a: 'You can export all your data (guests, reservations, billing history) before canceling. We keep your data for 30 days after cancellation.' },
          { q: 'Is it suitable for multi-property hotel groups?', a: 'Absolutely. Enterprise plan supports multiple properties under one account, each with their own branding and staff.' },
        ].map((item, i) => (
          <div key={i} style={{
            borderBottom: '1px solid var(--border2)',
            padding: '1.25rem 0',
          }}>
            <button onClick={() => setOpenFaq(openFaq === i ? null : i)} style={{
              width: '100%', textAlign: 'left', background: 'none', border: 'none',
              color: 'var(--white)', cursor: 'pointer', display: 'flex',
              justifyContent: 'space-between', alignItems: 'center', gap: '1rem',
              fontFamily: 'var(--font-body)', fontSize: '0.95rem', fontWeight: 400,
              lineHeight: 1.5,
            }}>
              <span>{item.q}</span>
              <span style={{
                color: 'var(--gold)', flexShrink: 0, fontSize: '1.2rem',
                transition: 'transform 0.2s',
                transform: openFaq === i ? 'rotate(45deg)' : 'rotate(0)',
              }}>+</span>
            </button>
            {openFaq === i && (
              <p style={{
                color: 'var(--silver)', fontSize: '0.875rem', lineHeight: 1.7,
                marginTop: '0.75rem', animation: 'fadeIn 0.2s ease',
              }}>{item.a}</p>
            )}
          </div>
        ))}
      </section>

      {/* CTA BANNER */}
      <section style={{
        padding: '6rem 2rem', textAlign: 'center',
        background: 'linear-gradient(135deg, rgba(200,169,110,0.1) 0%, rgba(200,169,110,0.04) 100%)',
        borderTop: '1px solid var(--border2)', borderBottom: '1px solid var(--border2)',
      }}>
        <h2 style={{
          fontFamily: 'var(--font-display)', fontSize: 'clamp(2rem, 4vw, 3.5rem)',
          marginBottom: '1rem',
          background: 'linear-gradient(135deg, var(--white), var(--gold))',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
        }}>
          Ready to launch your hotel CRM?
        </h2>
        <p style={{ color: 'var(--silver)', marginBottom: '2.5rem', fontSize: '1.1rem' }}>
          Join 500+ hotels already running on HotelOS. Start your free trial today.
        </p>
        <Link href="/auth/signup" style={{
          background: 'linear-gradient(135deg, var(--gold), var(--gold2))',
          color: '#080B10', padding: '1.1rem 3rem', borderRadius: 12,
          fontSize: '1.05rem', fontWeight: 600, textDecoration: 'none',
          boxShadow: '0 8px 40px rgba(200,169,110,0.3)',
        }}>
          Start for free — no card needed
        </Link>
      </section>

      {/* FOOTER */}
      <footer style={{
        padding: '3rem 2rem',
        borderTop: '1px solid var(--border2)',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        flexWrap: 'wrap', gap: '1rem', maxWidth: 1200, margin: '0 auto',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', color: 'var(--gold)' }}>HotelOS</span>
          <span style={{ color: 'var(--silver)', fontSize: '0.8rem' }}>© 2026</span>
        </div>
        <div style={{ display: 'flex', gap: '2rem' }}>
          {['Privacy', 'Terms', 'Contact'].map(l => (
            <a key={l} href="#" style={{ color: 'var(--silver)', fontSize: '0.8rem', textDecoration: 'none' }}>{l}</a>
          ))}
        </div>
      </footer>
    </div>
  )
}
