'use client'
import { useState, useEffect } from 'react'
import { createClient } from '../../lib/supabase'

const COLORS = ['#C8A96E', '#4ECBA3', '#6E9EC8', '#C86E9E', '#9EC86E', '#C8816E', '#B8A0D4', '#E8C462']

export default function SettingsPage() {
  const [tenant, setTenant] = useState(null)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [form, setForm] = useState({ hotel_name: '', primary_color: '#C8A96E', custom_domain: '', currency: 'USD', timezone: 'UTC' })

  useEffect(() => {
    const load = async () => {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      const { data: t } = await supabase.from('tenants').select('*').eq('owner_id', user.id).single()
      if (t) {
        setTenant(t)
        setForm({ hotel_name: t.hotel_name || '', primary_color: t.primary_color || '#C8A96E', custom_domain: t.custom_domain || '', currency: t.currency || 'USD', timezone: t.timezone || 'UTC' })
      }
    }
    load()
  }, [])

  const handleSave = async () => {
    setSaving(true)
    const supabase = createClient()
    await supabase.from('tenants').update(form).eq('id', tenant.id)
    setSaving(false)
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  const color = form.primary_color || '#C8A96E'

  const inputStyle = {
    width: '100%', background: 'rgba(255,255,255,0.05)',
    border: '1px solid var(--border)', borderRadius: 10,
    padding: '0.875rem 1rem', color: 'var(--white)',
    fontSize: '0.95rem', fontFamily: 'var(--font-body)', outline: 'none',
  }

  return (
    <div style={{ padding: '2.5rem', maxWidth: 640 }}>
      <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', marginBottom: '0.25rem' }}>Settings</h1>
      <p style={{ color: 'var(--silver)', marginBottom: '2.5rem', fontSize: '0.9rem' }}>Hotel branding & configuration</p>

      {/* Preview */}
      <div style={{
        background: 'var(--bg2)', border: `2px solid ${color}30`,
        borderRadius: 14, padding: '1.25rem', marginBottom: '2rem',
        display: 'flex', alignItems: 'center', gap: '0.75rem',
      }}>
        <div style={{
          width: 44, height: 44, borderRadius: 10,
          background: `linear-gradient(135deg, ${color}, ${color}99)`,
          display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.3rem',
        }}>🏨</div>
        <div>
          <div style={{ fontFamily: 'var(--font-display)', color, fontSize: '1.1rem' }}>{form.hotel_name || 'Hotel Name'}</div>
          <div style={{ fontSize: '0.7rem', color: 'var(--silver)' }}>Preview of your branding</div>
        </div>
      </div>

      <div style={{
        background: 'var(--bg2)', border: '1px solid var(--border2)',
        borderRadius: 16, padding: '2rem',
        display: 'flex', flexDirection: 'column', gap: '1.5rem',
      }}>
        <div>
          <label style={{ display: 'block', fontSize: '0.8rem', color: 'var(--silver)', marginBottom: '0.4rem' }}>Hotel name</label>
          <input style={inputStyle} value={form.hotel_name}
            onChange={e => setForm(f => ({ ...f, hotel_name: e.target.value }))}
            onFocus={e => e.target.style.borderColor = color}
            onBlur={e => e.target.style.borderColor = 'var(--border)'}
          />
        </div>

        <div>
          <label style={{ display: 'block', fontSize: '0.8rem', color: 'var(--silver)', marginBottom: '0.75rem' }}>Brand color</label>
          <div style={{ display: 'flex', gap: '0.6rem', flexWrap: 'wrap', alignItems: 'center' }}>
            {COLORS.map(c => (
              <div key={c} onClick={() => setForm(f => ({ ...f, primary_color: c }))} style={{
                width: 36, height: 36, borderRadius: '50%', background: c, cursor: 'pointer',
                border: color === c ? '3px solid white' : '3px solid transparent',
                boxShadow: color === c ? `0 0 0 2px ${c}` : 'none',
                transition: 'all 0.2s',
              }} />
            ))}
            <input type="color" value={color} onChange={e => setForm(f => ({ ...f, primary_color: e.target.value }))}
              style={{ width: 36, height: 36, borderRadius: '50%', border: 'none', cursor: 'pointer', background: 'none' }}
            />
          </div>
        </div>

        <div>
          <label style={{ display: 'block', fontSize: '0.8rem', color: 'var(--silver)', marginBottom: '0.4rem' }}>
            Custom domain <span style={{ color: 'var(--gold)', fontSize: '0.7rem' }}>Pro & Enterprise</span>
          </label>
          <input style={inputStyle} placeholder="app.yourhotel.com" value={form.custom_domain}
            onChange={e => setForm(f => ({ ...f, custom_domain: e.target.value }))}
            onFocus={e => e.target.style.borderColor = color}
            onBlur={e => e.target.style.borderColor = 'var(--border)'}
          />
          <p style={{ color: 'var(--silver)', fontSize: '0.75rem', marginTop: '0.4rem' }}>
            Add a CNAME record pointing to <span style={{ fontFamily: 'var(--font-mono)', color }}>cname.hotelos.app</span>
          </p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
          <div>
            <label style={{ display: 'block', fontSize: '0.8rem', color: 'var(--silver)', marginBottom: '0.4rem' }}>Currency</label>
            <select value={form.currency} onChange={e => setForm(f => ({ ...f, currency: e.target.value }))}
              style={{ ...inputStyle }}>
              <option value="USD">USD ($)</option>
              <option value="BDT">BDT (৳)</option>
              <option value="EUR">EUR (€)</option>
              <option value="GBP">GBP (£)</option>
              <option value="INR">INR (₹)</option>
              <option value="AED">AED (د.إ)</option>
            </select>
          </div>
          <div>
            <label style={{ display: 'block', fontSize: '0.8rem', color: 'var(--silver)', marginBottom: '0.4rem' }}>Timezone</label>
            <select value={form.timezone} onChange={e => setForm(f => ({ ...f, timezone: e.target.value }))}
              style={{ ...inputStyle }}>
              <option value="UTC">UTC</option>
              <option value="Asia/Dhaka">Asia/Dhaka</option>
              <option value="Asia/Kolkata">Asia/Kolkata</option>
              <option value="Asia/Dubai">Asia/Dubai</option>
              <option value="Europe/London">Europe/London</option>
              <option value="America/New_York">America/New_York</option>
            </select>
          </div>
        </div>

        <button onClick={handleSave} disabled={saving} style={{
          padding: '1rem', marginTop: '0.5rem',
          background: saved ? 'rgba(78,203,163,0.3)' : `linear-gradient(135deg, ${color}, ${color}cc)`,
          color: saved ? 'var(--success)' : '#080B10',
          border: saved ? '1px solid var(--success)' : 'none',
          borderRadius: 10, cursor: saving ? 'not-allowed' : 'pointer',
          fontSize: '0.95rem', fontWeight: 600, fontFamily: 'var(--font-body)',
          transition: 'all 0.3s',
        }}>
          {saved ? '✓ Saved!' : saving ? 'Saving...' : 'Save changes'}
        </button>
      </div>
    </div>
  )
}
