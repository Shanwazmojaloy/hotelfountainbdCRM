'use client'
import { useState, useEffect } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import Link from 'next/link'
import { createClient } from '../lib/supabase'

const NAV = [
  { href: '/dashboard', icon: '◈', label: 'Dashboard' },
  { href: '/dashboard/app', icon: '🏨', label: 'Hotel CRM' },
  { href: '/dashboard/billing', icon: '💳', label: 'Billing & Plan' },
  { href: '/dashboard/settings', icon: '⚙', label: 'Settings' },
]

export default function DashboardLayout({ children }) {
  const router = useRouter()
  const pathname = usePathname()
  const [tenant, setTenant] = useState(null)
  const [sub, setSub] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const load = async () => {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { router.push('/auth/login'); return }

      const { data: t } = await supabase
        .from('tenants').select('*').eq('owner_id', user.id).single()

      if (!t) { router.push('/auth/onboarding'); return }
      if (!t.onboarding_complete) { router.push('/auth/onboarding'); return }

      const { data: s } = await supabase
        .from('subscriptions').select('*').eq('tenant_id', t.id).single()

      setTenant(t)
      setSub(s)
      setLoading(false)
    }
    load()
  }, [router])

  const handleLogout = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push('/')
  }

  if (loading) return (
    <div style={{
      minHeight: '100vh', background: 'var(--bg)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{
          width: 48, height: 48, border: '2px solid var(--border)', borderTopColor: 'var(--gold)',
          borderRadius: '50%', animation: 'spin 0.8s linear infinite', margin: '0 auto 1rem',
        }} />
        <div style={{ color: 'var(--silver)', fontSize: '0.875rem' }}>Loading your hotel CRM...</div>
      </div>
    </div>
  )

  const color = tenant?.primary_color || '#C8A96E'
  const trialDaysLeft = sub?.trial_ends_at
    ? Math.max(0, Math.ceil((new Date(sub.trial_ends_at) - new Date()) / 86400000))
    : 0

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: 'var(--bg)' }}>
      {/* SIDEBAR */}
      <aside style={{
        width: 240, flexShrink: 0,
        background: 'var(--bg2)', borderRight: '1px solid var(--border2)',
        display: 'flex', flexDirection: 'column',
        position: 'fixed', top: 0, left: 0, bottom: 0, zIndex: 50,
      }}>
        {/* Hotel logo / name */}
        <div style={{ padding: '1.5rem', borderBottom: '1px solid var(--border2)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <div style={{
              width: 40, height: 40, borderRadius: 10,
              background: `linear-gradient(135deg, ${color}, ${color}99)`,
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.2rem',
              flexShrink: 0,
            }}>🏨</div>
            <div style={{ overflow: 'hidden' }}>
              <div style={{
                fontFamily: 'var(--font-display)', fontSize: '0.95rem',
                color, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
              }}>{tenant?.hotel_name}</div>
              <div style={{ fontSize: '0.65rem', color: 'var(--silver)', fontFamily: 'var(--font-mono)' }}>
                {sub?.plan?.toUpperCase()} · {sub?.status === 'trialing' ? `${trialDaysLeft}d trial` : 'ACTIVE'}
              </div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ padding: '1rem 0', flex: 1 }}>
          {NAV.map(item => {
            const active = pathname === item.href || (item.href !== '/dashboard' && pathname.startsWith(item.href))
            return (
              <Link key={item.href} href={item.href} style={{
                display: 'flex', alignItems: 'center', gap: '0.75rem',
                padding: '0.75rem 1.25rem', textDecoration: 'none',
                color: active ? color : 'var(--silver)',
                background: active ? `${color}12` : 'transparent',
                borderLeft: active ? `3px solid ${color}` : '3px solid transparent',
                fontSize: '0.875rem', transition: 'all 0.2s',
              }}>
                <span style={{ fontSize: '1rem' }}>{item.icon}</span>
                {item.label}
              </Link>
            )
          })}
        </nav>

        {/* Trial warning */}
        {sub?.status === 'trialing' && trialDaysLeft <= 7 && (
          <div style={{
            margin: '0 1rem 1rem',
            background: 'rgba(224,92,92,0.1)', border: '1px solid rgba(224,92,92,0.2)',
            borderRadius: 10, padding: '0.875rem',
          }}>
            <div style={{ fontSize: '0.75rem', color: '#E05C5C', fontWeight: 500 }}>
              ⚠ {trialDaysLeft} days left in trial
            </div>
            <Link href="/dashboard/billing" style={{
              fontSize: '0.7rem', color: 'var(--gold)', textDecoration: 'none', display: 'block', marginTop: '0.3rem',
            }}>Upgrade now →</Link>
          </div>
        )}

        {/* Logout */}
        <div style={{ padding: '1rem', borderTop: '1px solid var(--border2)' }}>
          <button onClick={handleLogout} style={{
            width: '100%', padding: '0.6rem', background: 'transparent',
            border: '1px solid var(--border2)', borderRadius: 8, color: 'var(--silver)',
            fontSize: '0.8rem', cursor: 'pointer', fontFamily: 'var(--font-body)',
            transition: 'all 0.2s',
          }}
            onMouseEnter={e => { e.target.style.color = 'var(--white)'; e.target.style.borderColor = 'var(--border)' }}
            onMouseLeave={e => { e.target.style.color = 'var(--silver)'; e.target.style.borderColor = 'var(--border2)' }}
          >
            Sign out
          </button>
        </div>
      </aside>

      {/* MAIN */}
      <main style={{ marginLeft: 240, flex: 1, minHeight: '100vh' }}>
        {children}
      </main>
    </div>
  )
}
