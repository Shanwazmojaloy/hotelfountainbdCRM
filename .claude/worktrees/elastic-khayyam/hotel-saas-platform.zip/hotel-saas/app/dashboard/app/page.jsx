'use client'
import { useState, useEffect } from 'react'
import { createClient } from '../../lib/supabase'
import HotelApp from './HotelApp'

export default function AppPage() {
  const [tenant, setTenant] = useState(null)
  const [sub, setSub] = useState(null)
  const [loading, setLoading] = useState(true)
  const [blocked, setBlocked] = useState(false)

  useEffect(() => {
    const load = async () => {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      const { data: t } = await supabase
        .from('tenants').select('*').eq('owner_id', user.id).single()
      const { data: s } = await supabase
        .from('subscriptions').select('*').eq('tenant_id', t?.id).single()

      if (s?.status === 'canceled' || s?.status === 'past_due') {
        setBlocked(true)
      }

      setTenant(t)
      setSub(s)
      setLoading(false)
    }
    load()
  }, [])

  if (loading) return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <div style={{ width: 40, height: 40, border: '2px solid var(--border)', borderTopColor: 'var(--gold)', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
    </div>
  )

  if (blocked) return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      textAlign: 'center', padding: '2rem',
    }}>
      <div>
        <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🔒</div>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.75rem', marginBottom: '0.5rem' }}>
          Subscription required
        </h2>
        <p style={{ color: 'var(--silver)', marginBottom: '2rem' }}>
          Your trial has ended or your subscription is past due.
        </p>
        <a href="/dashboard/billing" style={{
          background: 'linear-gradient(135deg, var(--gold), var(--gold2))',
          color: '#080B10', padding: '0.875rem 2rem', borderRadius: 10,
          textDecoration: 'none', fontWeight: 600,
        }}>Upgrade to continue →</a>
      </div>
    </div>
  )

  return (
    <div style={{ height: '100vh', overflow: 'hidden' }}>
      <HotelApp
        tenantId={tenant?.id}
        hotelName={tenant?.hotel_name}
        primaryColor={tenant?.primary_color || '#C8A96E'}
        currency={tenant?.currency || 'USD'}
        isWhiteLabel={tenant?.is_white_label}
        plan={sub?.plan || 'starter'}
      />
    </div>
  )
}
