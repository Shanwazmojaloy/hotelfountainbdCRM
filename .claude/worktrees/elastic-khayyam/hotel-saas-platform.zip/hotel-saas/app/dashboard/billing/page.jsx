'use client'
import { useState, useEffect } from 'react'
import { createClient } from '../../lib/supabase'
import { PLANS } from '../../lib/plans'

export default function BillingPage() {
  const [tenant, setTenant] = useState(null)
  const [sub, setSub] = useState(null)
  const [loading, setLoading] = useState(true)
  const [checkoutLoading, setCheckoutLoading] = useState('')

  useEffect(() => {
    const load = async () => {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      const { data: t } = await supabase.from('tenants').select('*').eq('owner_id', user.id).single()
      const { data: s } = await supabase.from('subscriptions').select('*').eq('tenant_id', t?.id).single()
      setTenant(t); setSub(s); setLoading(false)
    }
    load()
  }, [])

  const handleCheckout = async (planId) => {
    setCheckoutLoading(planId)
    try {
      const supabase = createClient()
      const { data: { session } } = await supabase.auth.getSession()
      const res = await fetch('/api/stripe/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.access_token}` },
        body: JSON.stringify({ planId, tenantId: tenant.id }),
      })
      const { url } = await res.json()
      if (url) window.location.href = url
    } catch (err) {
      alert('Failed to start checkout: ' + err.message)
    } finally {
      setCheckoutLoading('')
    }
  }

  const color = tenant?.primary_color || '#C8A96E'
  const trialDaysLeft = sub?.trial_ends_at
    ? Math.max(0, Math.ceil((new Date(sub.trial_ends_at) - new Date()) / 86400000))
    : 0

  if (loading) return (
    <div style={{ padding: '2.5rem' }}>
      <div style={{ height: 200, background: 'var(--bg2)', borderRadius: 16, animation: 'shimmer 1.5s ease infinite' }} />
    </div>
  )

  return (
    <div style={{ padding: '2.5rem', maxWidth: 900 }}>
      <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', marginBottom: '0.25rem' }}>Billing & Plan</h1>
      <p style={{ color: 'var(--silver)', marginBottom: '2.5rem', fontSize: '0.9rem' }}>Manage your subscription</p>

      {/* Current plan */}
      <div style={{
        background: 'var(--bg2)', border: `1px solid ${color}30`,
        borderRadius: 16, padding: '1.75rem', marginBottom: '2rem',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <div style={{ fontSize: '0.75rem', color: 'var(--silver)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: '0.5rem' }}>Current plan</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.75rem', color, marginBottom: '0.25rem' }}>
              {PLANS[sub?.plan]?.name || sub?.plan}
            </div>
            <div style={{ fontSize: '0.875rem', color: 'var(--silver)' }}>
              {sub?.status === 'trialing'
                ? `Free trial · ${trialDaysLeft} days remaining`
                : sub?.status === 'active'
                  ? `Active · renews ${sub.current_period_end ? new Date(sub.current_period_end).toLocaleDateString() : '—'}`
                  : sub?.status}
            </div>
          </div>
          <div style={{
            padding: '0.4rem 1rem', borderRadius: 100,
            background: sub?.status === 'active' ? 'rgba(78,203,163,0.15)' : sub?.status === 'trialing' ? `${color}20` : 'rgba(224,92,92,0.15)',
            color: sub?.status === 'active' ? 'var(--success)' : sub?.status === 'trialing' ? color : 'var(--danger)',
            fontSize: '0.75rem', fontWeight: 500,
          }}>
            {sub?.status?.toUpperCase()}
          </div>
        </div>
      </div>

      {/* Plan cards */}
      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', marginBottom: '1.25rem' }}>
        {sub?.status === 'active' ? 'Change plan' : 'Choose a plan to subscribe'}
      </h2>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1rem' }}>
        {Object.values(PLANS).map(plan => {
          const isCurrent = sub?.plan === plan.id && sub?.status === 'active'
          return (
            <div key={plan.id} style={{
              background: 'var(--bg2)', border: `1px solid ${isCurrent ? color + '50' : 'var(--border2)'}`,
              borderRadius: 16, padding: '1.5rem',
              boxShadow: isCurrent ? `0 0 0 1px ${color}30` : 'none',
            }}>
              <div style={{ marginBottom: '1rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.2rem' }}>{plan.name}</h3>
                  {isCurrent && (
                    <span style={{ fontSize: '0.65rem', background: color, color: '#080B10', padding: '2px 8px', borderRadius: 100, fontWeight: 700 }}>CURRENT</span>
                  )}
                </div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', color, margin: '0.5rem 0' }}>
                  ${plan.price}<span style={{ fontSize: '0.875rem', color: 'var(--silver)', fontFamily: 'var(--font-body)' }}>/mo</span>
                </div>
              </div>

              <ul style={{ listStyle: 'none', marginBottom: '1.5rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                {plan.features.slice(0, 4).map(f => (
                  <li key={f} style={{ display: 'flex', gap: '0.5rem', fontSize: '0.8rem', color: 'var(--silver)' }}>
                    <span style={{ color }}>✓</span> {f}
                  </li>
                ))}
              </ul>

              <button
                onClick={() => !isCurrent && handleCheckout(plan.id)}
                disabled={isCurrent || checkoutLoading === plan.id}
                style={{
                  width: '100%', padding: '0.75rem',
                  background: isCurrent ? 'rgba(255,255,255,0.04)' : `linear-gradient(135deg, ${color}, ${color}cc)`,
                  color: isCurrent ? 'var(--silver)' : '#080B10',
                  border: isCurrent ? '1px solid var(--border2)' : 'none',
                  borderRadius: 8, cursor: isCurrent ? 'default' : 'pointer',
                  fontSize: '0.875rem', fontWeight: 500, fontFamily: 'var(--font-body)',
                }}
              >
                {isCurrent ? 'Current plan' : checkoutLoading === plan.id ? 'Loading...' : `Subscribe to ${plan.name}`}
              </button>
            </div>
          )
        })}
      </div>

      <p style={{ marginTop: '1.5rem', fontSize: '0.8rem', color: 'var(--silver)', textAlign: 'center' }}>
        Payments secured by Stripe. Cancel anytime from your Stripe billing portal.
      </p>
    </div>
  )
}
