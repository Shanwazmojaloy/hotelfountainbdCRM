'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { createClient } from '../lib/supabase'

export default function DashboardHome() {
  const [tenant, setTenant] = useState(null)
  const [sub, setSub] = useState(null)
  const [stats, setStats] = useState({ rooms: 0, guests: 0, reservations: 0 })

  useEffect(() => {
    const load = async () => {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      const { data: t } = await supabase
        .from('tenants').select('*').eq('owner_id', user.id).single()
      const { data: s } = await supabase
        .from('subscriptions').select('*').eq('tenant_id', t?.id).single()

      if (t) {
        setTenant(t)
        setSub(s)

        const [rooms, guests, reservations] = await Promise.all([
          supabase.from('tenant_rooms').select('id', { count: 'exact' }).eq('tenant_id', t.id),
          supabase.from('tenant_guests').select('id', { count: 'exact' }).eq('tenant_id', t.id),
          supabase.from('tenant_reservations').select('id', { count: 'exact' }).eq('tenant_id', t.id),
        ])
        setStats({
          rooms: rooms.count || 0,
          guests: guests.count || 0,
          reservations: reservations.count || 0,
        })
      }
    }
    load()
  }, [])

  const color = tenant?.primary_color || '#C8A96E'
  const trialDaysLeft = sub?.trial_ends_at
    ? Math.max(0, Math.ceil((new Date(sub.trial_ends_at) - new Date()) / 86400000))
    : 0

  return (
    <div style={{ padding: '2.5rem', maxWidth: 1000 }}>
      {/* Header */}
      <div style={{ marginBottom: '2.5rem' }}>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', marginBottom: '0.25rem' }}>
          Welcome back 👋
        </h1>
        <p style={{ color: 'var(--silver)', fontSize: '0.9rem' }}>
          {tenant?.hotel_name} — {sub?.plan?.toUpperCase()} plan
        </p>
      </div>

      {/* Trial banner */}
      {sub?.status === 'trialing' && (
        <div style={{
          background: `${color}12`, border: `1px solid ${color}30`,
          borderRadius: 12, padding: '1.25rem 1.5rem', marginBottom: '2rem',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          flexWrap: 'wrap', gap: '1rem',
        }}>
          <div>
            <div style={{ fontWeight: 500, marginBottom: '0.25rem' }}>
              🎁 Free trial — {trialDaysLeft} days remaining
            </div>
            <div style={{ color: 'var(--silver)', fontSize: '0.875rem' }}>
              Upgrade to keep access to all features after your trial ends.
            </div>
          </div>
          <Link href="/dashboard/billing" style={{
            background: `linear-gradient(135deg, ${color}, ${color}cc)`,
            color: '#080B10', padding: '0.6rem 1.5rem', borderRadius: 8,
            textDecoration: 'none', fontSize: '0.875rem', fontWeight: 600,
          }}>
            Upgrade now
          </Link>
        </div>
      )}

      {/* Quick stats */}
      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))',
        gap: '1rem', marginBottom: '2.5rem',
      }}>
        {[
          { label: 'Rooms', value: stats.rooms, icon: '🛏' },
          { label: 'Guests', value: stats.guests, icon: '👥' },
          { label: 'Reservations', value: stats.reservations, icon: '📋' },
          { label: 'Plan', value: sub?.plan || '—', icon: '⭐' },
        ].map(stat => (
          <div key={stat.label} style={{
            background: 'var(--bg2)', border: '1px solid var(--border2)',
            borderRadius: 14, padding: '1.25rem',
          }}>
            <div style={{ fontSize: '1.5rem', marginBottom: '0.75rem' }}>{stat.icon}</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.8rem', color, marginBottom: '0.2rem' }}>
              {stat.value}
            </div>
            <div style={{ color: 'var(--silver)', fontSize: '0.8rem' }}>{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Quick actions */}
      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', marginBottom: '1rem' }}>
        Quick actions
      </h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '1rem' }}>
        {[
          { href: '/dashboard/app', label: 'Open Hotel CRM', icon: '🏨', desc: 'Manage rooms, guests & reservations' },
          { href: '/dashboard/billing', label: 'Manage billing', icon: '💳', desc: 'Subscription, invoices, upgrade' },
          { href: '/dashboard/settings', label: 'Hotel settings', icon: '⚙', desc: 'Branding, domain, team members' },
        ].map(item => (
          <Link key={item.href} href={item.href} style={{
            background: 'var(--bg2)', border: '1px solid var(--border2)',
            borderRadius: 14, padding: '1.5rem', textDecoration: 'none', color: 'var(--white)',
            transition: 'all 0.2s', display: 'block',
          }}
            onMouseEnter={e => {
              e.currentTarget.style.borderColor = `${color}40`
              e.currentTarget.style.transform = 'translateY(-2px)'
            }}
            onMouseLeave={e => {
              e.currentTarget.style.borderColor = 'var(--border2)'
              e.currentTarget.style.transform = 'translateY(0)'
            }}
          >
            <div style={{ fontSize: '1.75rem', marginBottom: '0.75rem' }}>{item.icon}</div>
            <div style={{ fontWeight: 500, marginBottom: '0.3rem' }}>{item.label}</div>
            <div style={{ color: 'var(--silver)', fontSize: '0.8rem' }}>{item.desc}</div>
          </Link>
        ))}
      </div>
    </div>
  )
}
