'use client'
import { useState, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { createClient } from '../../lib/supabase'
import { PLANS } from '../../lib/plans'

function SignupForm() {
  const router = useRouter()
  const params = useSearchParams()
  const plan = params.get('plan') || 'pro'

  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const [form, setForm] = useState({
    name: '', email: '', password: '',
    hotelName: '', hotelSlug: '',
    selectedPlan: plan,
  })

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))

  const slugify = (str) => str.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')

  const handleHotelName = (v) => {
    set('hotelName', v)
    set('hotelSlug', slugify(v))
  }

  const handleSignup = async () => {
    setLoading(true)
    setError('')
    try {
      const supabase = createClient()

      // 1. Create auth user
      const { data: authData, error: authErr } = await supabase.auth.signUp({
        email: form.email,
        password: form.password,
        options: { data: { name: form.name } },
      })
      if (authErr) throw authErr

      const userId = authData.user?.id
      if (!userId) throw new Error('Signup failed — please try again')

      // 2. Create tenant
      const { data: tenant, error: tenantErr } = await supabase
        .from('tenants')
        .insert({
          owner_id: userId,
          hotel_name: form.hotelName,
          hotel_slug: form.hotelSlug,
          is_white_label: ['pro', 'enterprise'].includes(form.selectedPlan),
        })
        .select()
        .single()
      if (tenantErr) throw tenantErr

      // 3. Create subscription (trial)
      await supabase.from('subscriptions').insert({
        tenant_id: tenant.id,
        plan: form.selectedPlan,
        status: 'trialing',
      })

      // 4. Create tenant_user (owner)
      await supabase.from('tenant_users').insert({
        tenant_id: tenant.id,
        user_id: userId,
        role: 'superadmin',
        name: form.name,
        email: form.email,
        is_owner: true,
      })

      // Go to onboarding
      router.push('/auth/onboarding')
    } catch (err) {
      setError(err.message || 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }

  const inputStyle = {
    width: '100%', background: 'rgba(255,255,255,0.05)',
    border: '1px solid var(--border)', borderRadius: 10,
    padding: '0.875rem 1rem', color: 'var(--white)',
    fontSize: '0.95rem', fontFamily: 'var(--font-body)', outline: 'none',
    transition: 'border-color 0.2s',
  }

  const labelStyle = {
    display: 'block', fontSize: '0.8rem', color: 'var(--silver)',
    marginBottom: '0.4rem', letterSpacing: '0.03em',
  }

  return (
    <div style={{
      minHeight: '100vh', background: 'var(--bg)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: '2rem',
      backgroundImage: 'radial-gradient(ellipse 60% 40% at 50% 0%, rgba(200,169,110,0.1) 0%, transparent 70%)',
    }}>
      <div style={{ width: '100%', maxWidth: 480 }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
          <Link href="/" style={{ textDecoration: 'none' }}>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: '1.8rem', color: 'var(--gold)' }}>HotelOS</span>
          </Link>
          <p style={{ color: 'var(--silver)', fontSize: '0.875rem', marginTop: '0.5rem' }}>
            Create your account — 14 days free
          </p>
        </div>

        {/* Step indicator */}
        <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '2rem', justifyContent: 'center' }}>
          {[1, 2, 3].map(s => (
            <div key={s} style={{
              height: 3, borderRadius: 2, flex: 1,
              background: s <= step ? 'var(--gold)' : 'var(--border)',
              transition: 'background 0.3s',
              maxWidth: 80,
            }} />
          ))}
        </div>

        <div style={{
          background: 'var(--bg2)', border: '1px solid var(--border2)',
          borderRadius: 20, padding: '2rem',
        }}>
          {error && (
            <div style={{
              background: 'rgba(224,92,92,0.1)', border: '1px solid rgba(224,92,92,0.3)',
              borderRadius: 8, padding: '0.75rem 1rem',
              color: '#E05C5C', fontSize: '0.875rem', marginBottom: '1.5rem',
            }}>{error}</div>
          )}

          {/* STEP 1: Account */}
          {step === 1 && (
            <div style={{ animation: 'fadeUp 0.3s ease' }}>
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem', marginBottom: '0.25rem' }}>Create your account</h2>
              <p style={{ color: 'var(--silver)', fontSize: '0.875rem', marginBottom: '1.5rem' }}>Step 1 of 3</p>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <div>
                  <label style={labelStyle}>Your name</label>
                  <input
                    style={inputStyle} placeholder="Full name"
                    value={form.name} onChange={e => set('name', e.target.value)}
                    onFocus={e => e.target.style.borderColor = 'var(--gold)'}
                    onBlur={e => e.target.style.borderColor = 'var(--border)'}
                  />
                </div>
                <div>
                  <label style={labelStyle}>Email address</label>
                  <input
                    type="email" style={inputStyle} placeholder="you@hotel.com"
                    value={form.email} onChange={e => set('email', e.target.value)}
                    onFocus={e => e.target.style.borderColor = 'var(--gold)'}
                    onBlur={e => e.target.style.borderColor = 'var(--border)'}
                  />
                </div>
                <div>
                  <label style={labelStyle}>Password</label>
                  <input
                    type="password" style={inputStyle} placeholder="Min. 8 characters"
                    value={form.password} onChange={e => set('password', e.target.value)}
                    onFocus={e => e.target.style.borderColor = 'var(--gold)'}
                    onBlur={e => e.target.style.borderColor = 'var(--border)'}
                  />
                </div>
              </div>

              <button
                onClick={() => {
                  if (!form.name || !form.email || form.password.length < 8) {
                    setError('Please fill all fields (password min 8 chars)')
                    return
                  }
                  setError('')
                  setStep(2)
                }}
                style={{
                  width: '100%', marginTop: '2rem', padding: '1rem',
                  background: 'linear-gradient(135deg, var(--gold), var(--gold2))',
                  color: '#080B10', borderRadius: 10, border: 'none',
                  fontSize: '1rem', fontWeight: 600, cursor: 'pointer',
                  fontFamily: 'var(--font-body)',
                }}
              >
                Continue →
              </button>
            </div>
          )}

          {/* STEP 2: Hotel Info */}
          {step === 2 && (
            <div style={{ animation: 'fadeUp 0.3s ease' }}>
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem', marginBottom: '0.25rem' }}>Your hotel</h2>
              <p style={{ color: 'var(--silver)', fontSize: '0.875rem', marginBottom: '1.5rem' }}>Step 2 of 3</p>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <div>
                  <label style={labelStyle}>Hotel name</label>
                  <input
                    style={inputStyle} placeholder="Grand Palace Hotel"
                    value={form.hotelName} onChange={e => handleHotelName(e.target.value)}
                    onFocus={e => e.target.style.borderColor = 'var(--gold)'}
                    onBlur={e => e.target.style.borderColor = 'var(--border)'}
                  />
                </div>
                <div>
                  <label style={labelStyle}>Hotel slug (for your app URL)</label>
                  <div style={{ position: 'relative' }}>
                    <span style={{
                      position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)',
                      color: 'var(--silver)', fontSize: '0.875rem', fontFamily: 'var(--font-mono)',
                    }}>app/</span>
                    <input
                      style={{ ...inputStyle, paddingLeft: '3rem', fontFamily: 'var(--font-mono)' }}
                      placeholder="grand-palace-hotel"
                      value={form.hotelSlug} onChange={e => set('hotelSlug', slugify(e.target.value))}
                      onFocus={e => e.target.style.borderColor = 'var(--gold)'}
                      onBlur={e => e.target.style.borderColor = 'var(--border)'}
                    />
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '0.75rem', marginTop: '2rem' }}>
                <button onClick={() => setStep(1)} style={{
                  flex: 1, padding: '1rem', background: 'rgba(255,255,255,0.06)',
                  border: '1px solid var(--border)', color: 'var(--white)', borderRadius: 10,
                  cursor: 'pointer', fontSize: '0.95rem', fontFamily: 'var(--font-body)',
                }}>← Back</button>
                <button
                  onClick={() => {
                    if (!form.hotelName || !form.hotelSlug) {
                      setError('Please enter your hotel name')
                      return
                    }
                    setError('')
                    setStep(3)
                  }}
                  style={{
                    flex: 2, padding: '1rem',
                    background: 'linear-gradient(135deg, var(--gold), var(--gold2))',
                    color: '#080B10', borderRadius: 10, border: 'none',
                    fontSize: '1rem', fontWeight: 600, cursor: 'pointer',
                    fontFamily: 'var(--font-body)',
                  }}
                >Continue →</button>
              </div>
            </div>
          )}

          {/* STEP 3: Plan selection */}
          {step === 3 && (
            <div style={{ animation: 'fadeUp 0.3s ease' }}>
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem', marginBottom: '0.25rem' }}>Choose your plan</h2>
              <p style={{ color: 'var(--silver)', fontSize: '0.875rem', marginBottom: '1.5rem' }}>Step 3 of 3 — all plans include 14-day free trial</p>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1.5rem' }}>
                {Object.values(PLANS).map(p => (
                  <div
                    key={p.id}
                    onClick={() => set('selectedPlan', p.id)}
                    style={{
                      border: `1px solid ${form.selectedPlan === p.id ? 'var(--gold)' : 'var(--border2)'}`,
                      borderRadius: 12, padding: '1rem 1.25rem',
                      cursor: 'pointer', transition: 'all 0.2s',
                      background: form.selectedPlan === p.id ? 'rgba(200,169,110,0.08)' : 'transparent',
                      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                    }}
                  >
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <span style={{ fontWeight: 500 }}>{p.name}</span>
                        {p.highlight && (
                          <span style={{
                            fontSize: '0.65rem', background: 'var(--gold)', color: '#080B10',
                            padding: '2px 8px', borderRadius: 100, fontWeight: 700,
                          }}>POPULAR</span>
                        )}
                      </div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--silver)', marginTop: '0.2rem' }}>{p.tagline}</div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontFamily: 'var(--font-display)', color: 'var(--gold)' }}>${p.price}</div>
                      <div style={{ fontSize: '0.7rem', color: 'var(--silver)' }}>/month</div>
                    </div>
                  </div>
                ))}
              </div>

              <div style={{ display: 'flex', gap: '0.75rem' }}>
                <button onClick={() => setStep(2)} style={{
                  flex: 1, padding: '1rem', background: 'rgba(255,255,255,0.06)',
                  border: '1px solid var(--border)', color: 'var(--white)', borderRadius: 10,
                  cursor: 'pointer', fontSize: '0.95rem', fontFamily: 'var(--font-body)',
                }}>← Back</button>
                <button
                  onClick={handleSignup}
                  disabled={loading}
                  style={{
                    flex: 2, padding: '1rem',
                    background: loading ? 'rgba(200,169,110,0.4)' : 'linear-gradient(135deg, var(--gold), var(--gold2))',
                    color: '#080B10', borderRadius: 10, border: 'none',
                    fontSize: '1rem', fontWeight: 600, cursor: loading ? 'not-allowed' : 'pointer',
                    fontFamily: 'var(--font-body)',
                  }}
                >
                  {loading ? 'Creating your CRM...' : 'Start free trial →'}
                </button>
              </div>
            </div>
          )}
        </div>

        <p style={{ textAlign: 'center', marginTop: '1.5rem', fontSize: '0.875rem', color: 'var(--silver)' }}>
          Already have an account?{' '}
          <Link href="/auth/login" style={{ color: 'var(--gold)', textDecoration: 'none' }}>Sign in</Link>
        </p>
      </div>
    </div>
  )
}

export default function SignupPage() {
  return (
    <Suspense>
      <SignupForm />
    </Suspense>
  )
}
