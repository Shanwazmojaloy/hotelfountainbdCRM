'use client'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '../../lib/supabase'

const COLORS = ['#C8A96E', '#4ECBA3', '#6E9EC8', '#C86E9E', '#9EC86E', '#C8816E']

export default function OnboardingPage() {
  const router = useRouter()
  const [tenant, setTenant] = useState(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  const [hotelName, setHotelName] = useState('')
  const [primaryColor, setPrimaryColor] = useState('#C8A96E')
  const [currency, setCurrency] = useState('USD')
  const [timezone, setTimezone] = useState('UTC')

  useEffect(() => {
    const load = async () => {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { router.push('/auth/login'); return }

      const { data: t } = await supabase
        .from('tenants')
        .select('*')
        .eq('owner_id', user.id)
        .single()

      if (t) {
        setTenant(t)
        setHotelName(t.hotel_name || '')
        setPrimaryColor(t.primary_color || '#C8A96E')
        setCurrency(t.currency || 'USD')
        setTimezone(t.timezone || 'UTC')
      }
      setLoading(false)
    }
    load()
  }, [router])

  const handleSave = async () => {
    if (!tenant) return
    setSaving(true)
    const supabase = createClient()
    await supabase.from('tenants').update({
      hotel_name: hotelName,
      primary_color: primaryColor,
      currency,
      timezone,
      onboarding_complete: true,
    }).eq('id', tenant.id)
    router.push('/dashboard')
  }

  if (loading) return (
    <div style={{
      minHeight: '100vh', background: 'var(--bg)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <div style={{ width: 40, height: 40, border: '2px solid var(--border)', borderTopColor: 'var(--gold)', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
    </div>
  )

  return (
    <div style={{
      minHeight: '100vh', background: 'var(--bg)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: '2rem',
      backgroundImage: 'radial-gradient(ellipse 60% 40% at 50% 0%, rgba(200,169,110,0.08) 0%, transparent 70%)',
    }}>
      <div style={{ width: '100%', maxWidth: 520 }}>
        <div style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
          <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🎨</div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', marginBottom: '0.5rem' }}>
            Set up your hotel
          </h1>
          <p style={{ color: 'var(--silver)', fontSize: '0.9rem' }}>
            Customize your CRM to match your brand
          </p>
        </div>

        <div style={{
          background: 'var(--bg2)', border: '1px solid var(--border2)',
          borderRadius: 20, padding: '2rem',
          display: 'flex', flexDirection: 'column', gap: '1.5rem',
        }}>
          {/* Preview card */}
          <div style={{
            background: 'var(--bg3)', borderRadius: 12, padding: '1.25rem',
            border: `2px solid ${primaryColor}30`,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <div style={{
                width: 40, height: 40, borderRadius: 10,
                background: `linear-gradient(135deg, ${primaryColor}, ${primaryColor}aa)`,
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.2rem',
              }}>🏨</div>
              <div>
                <div style={{ fontFamily: 'var(--font-display)', color: primaryColor, fontSize: '1.1rem' }}>
                  {hotelName || 'Your Hotel Name'}
                </div>
                <div style={{ fontSize: '0.75rem', color: 'var(--silver)' }}>Hotel Management System</div>
              </div>
            </div>
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.8rem', color: 'var(--silver)', marginBottom: '0.4rem' }}>Hotel name</label>
            <input
              style={{
                width: '100%', background: 'rgba(255,255,255,0.05)',
                border: '1px solid var(--border)', borderRadius: 10,
                padding: '0.875rem 1rem', color: 'var(--white)',
                fontSize: '0.95rem', fontFamily: 'var(--font-body)', outline: 'none',
              }}
              value={hotelName}
              onChange={e => setHotelName(e.target.value)}
              onFocus={e => e.target.style.borderColor = primaryColor}
              onBlur={e => e.target.style.borderColor = 'var(--border)'}
            />
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.8rem', color: 'var(--silver)', marginBottom: '0.75rem' }}>Brand color</label>
            <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
              {COLORS.map(c => (
                <div
                  key={c}
                  onClick={() => setPrimaryColor(c)}
                  style={{
                    width: 40, height: 40, borderRadius: '50%', background: c,
                    cursor: 'pointer', border: primaryColor === c ? '3px solid white' : '3px solid transparent',
                    boxShadow: primaryColor === c ? `0 0 0 2px ${c}` : 'none',
                    transition: 'all 0.2s',
                  }}
                />
              ))}
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <input type="color" value={primaryColor} onChange={e => setPrimaryColor(e.target.value)}
                  style={{ width: 40, height: 40, borderRadius: '50%', border: 'none', cursor: 'pointer', background: 'none' }}
                />
              </div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.8rem', color: 'var(--silver)', marginBottom: '0.4rem' }}>Currency</label>
              <select
                value={currency} onChange={e => setCurrency(e.target.value)}
                style={{
                  width: '100%', background: 'rgba(255,255,255,0.05)',
                  border: '1px solid var(--border)', borderRadius: 10,
                  padding: '0.875rem 1rem', color: 'var(--white)',
                  fontSize: '0.875rem', outline: 'none',
                }}
              >
                <option value="USD">USD ($)</option>
                <option value="BDT">BDT (৳)</option>
                <option value="EUR">EUR (€)</option>
                <option value="GBP">GBP (£)</option>
                <option value="INR">INR (₹)</option>
                <option value="AED">AED (د.إ)</option>
              </select>
            </div>
            <div>
              <label style={{ display: 'block', fontSize: '0.8rem', color: 'var(--silver)', marginBottom: '0.4rem' }}>Timezone</label>
              <select
                value={timezone} onChange={e => setTimezone(e.target.value)}
                style={{
                  width: '100%', background: 'rgba(255,255,255,0.05)',
                  border: '1px solid var(--border)', borderRadius: 10,
                  padding: '0.875rem 1rem', color: 'var(--white)',
                  fontSize: '0.875rem', outline: 'none',
                }}
              >
                <option value="UTC">UTC</option>
                <option value="Asia/Dhaka">Asia/Dhaka</option>
                <option value="Asia/Kolkata">Asia/Kolkata</option>
                <option value="Asia/Dubai">Asia/Dubai</option>
                <option value="Europe/London">Europe/London</option>
                <option value="America/New_York">America/New_York</option>
              </select>
            </div>
          </div>

          <button
            onClick={handleSave}
            disabled={saving || !hotelName}
            style={{
              padding: '1rem', marginTop: '0.5rem',
              background: saving || !hotelName ? 'rgba(200,169,110,0.4)' : `linear-gradient(135deg, ${primaryColor}, ${primaryColor}cc)`,
              color: '#080B10', borderRadius: 10, border: 'none',
              fontSize: '1rem', fontWeight: 600, cursor: saving || !hotelName ? 'not-allowed' : 'pointer',
              fontFamily: 'var(--font-body)',
            }}
          >
            {saving ? 'Setting up your CRM...' : 'Launch my hotel CRM →'}
          </button>
        </div>
      </div>
    </div>
  )
}
