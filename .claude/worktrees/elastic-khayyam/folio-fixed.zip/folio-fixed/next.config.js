/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [],
  },
  // Ensure production build works without optional env vars
  env: {},
}

module.exports = nextConfig
