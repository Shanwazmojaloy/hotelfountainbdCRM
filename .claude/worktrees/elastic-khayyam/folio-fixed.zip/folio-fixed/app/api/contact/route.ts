import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const { name, email, message } = await req.json()

    if (!name || !email || !message) {
      return NextResponse.json({ error: 'Missing fields' }, { status: 400 })
    }

    // Log the contact (you can connect email service like Resend here later)
    console.log('Contact form submission:', { name, email, message: message.slice(0, 100) })

    // TODO: integrate Resend or similar:
    // const resend = new Resend(process.env.RESEND_API_KEY)
    // await resend.emails.send({ from: 'folio@yourdomain.com', to: 'ahmedshanwaz5@gmail.com', subject: `New message from ${name}`, text: message })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Contact route error:', error)
    return NextResponse.json({ error: 'Internal error' }, { status: 500 })
  }
}
