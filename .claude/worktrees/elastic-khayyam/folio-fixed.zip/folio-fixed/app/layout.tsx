import type { Metadata } from 'next'
import { GeistSans } from 'geist/font/sans'
import { GeistMono } from 'geist/font/mono'
import './globals.css'

export const metadata: Metadata = {
  title: 'Shanwaz Ahmed — Portfolio',
  description: 'Full-stack developer & designer. Building digital products with clean code and purposeful design.',
  openGraph: {
    title: 'Shanwaz Ahmed — Portfolio',
    description: 'Full-stack developer & designer.',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${GeistSans.variable} ${GeistMono.variable}`}>
      <body className="bg-[#080B10] text-white antialiased">
        {children}
      </body>
    </html>
  )
}
