export default function Footer() {
  return (
    <footer
      className="py-8 px-6 border-t text-center text-sm"
      style={{
        borderColor: 'rgba(200,169,110,0.08)',
        color: 'var(--silver)',
      }}
    >
      <div className="max-w-6xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-4">
        <span className="font-mono" style={{ color: 'var(--gold)' }}>
          SA<span style={{ color: 'var(--silver)' }}>.</span>
        </span>
        <span>
          Built with Next.js 15 · © {new Date().getFullYear()} Shanwaz Ahmed
        </span>
        <div className="flex gap-4">
          <a
            href="https://github.com/Shanwazmojaloy"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-white transition-colors"
          >
            GitHub
          </a>
          <a
            href="mailto:ahmedshanwaz5@gmail.com"
            className="hover:text-white transition-colors"
          >
            Email
          </a>
        </div>
      </div>
    </footer>
  )
}
