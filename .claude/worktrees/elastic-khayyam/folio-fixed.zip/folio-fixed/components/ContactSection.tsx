'use client'

import { useState } from 'react'

export default function ContactSection() {
  const [form, setForm] = useState({ name: '', email: '', message: '' })
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name || !form.email || !form.message) return
    setStatus('loading')

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      if (res.ok) {
        setStatus('success')
        setForm({ name: '', email: '', message: '' })
      } else {
        setStatus('error')
      }
    } catch {
      setStatus('error')
    }
  }

  const inputCls =
    'w-full rounded-xl px-4 py-3 text-sm outline-none transition-all duration-200 focus:ring-1'
  const inputStyle = {
    background: 'rgba(255,255,255,0.05)',
    border: '1px solid rgba(200,169,110,0.15)',
    color: 'white',
  }

  return (
    <section
      id="contact"
      className="py-24 px-6"
      style={{
        background:
          'linear-gradient(180deg, transparent 0%, rgba(200,169,110,0.04) 50%, transparent 100%)',
      }}
    >
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <p
            className="text-xs tracking-widest uppercase mb-3 font-mono"
            style={{ color: 'var(--gold)' }}
          >
            Get in touch
          </p>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Let&apos;s work together
          </h2>
          <p style={{ color: 'var(--silver)' }}>
            Have a project in mind? I&apos;d love to hear about it. Send me a message and I&apos;ll
            get back to you within 24 hours.
          </p>
        </div>

        <div
          className="rounded-2xl p-8 border"
          style={{
            background: 'var(--bg2)',
            borderColor: 'rgba(200,169,110,0.1)',
          }}
        >
          {status === 'success' ? (
            <div className="text-center py-8">
              <div className="text-4xl mb-4">✅</div>
              <h3 className="text-xl font-semibold mb-2">Message sent!</h3>
              <p style={{ color: 'var(--silver)' }}>
                Thanks for reaching out. I&apos;ll reply to {form.email || 'you'} within 24 hours.
              </p>
              <button
                onClick={() => setStatus('idle')}
                className="mt-6 text-sm px-4 py-2 rounded-lg border transition-all hover:opacity-80"
                style={{ borderColor: 'rgba(200,169,110,0.2)', color: 'var(--gold)' }}
              >
                Send another
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid md:grid-cols-2 gap-5">
                <div>
                  <label
                    className="block text-xs mb-1.5 font-mono"
                    style={{ color: 'var(--silver)' }}
                  >
                    Name
                  </label>
                  <input
                    type="text"
                    className={inputCls}
                    style={inputStyle}
                    placeholder="Your name"
                    value={form.name}
                    onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                    onFocus={(e) => (e.target.style.borderColor = 'rgba(200,169,110,0.5)')}
                    onBlur={(e) => (e.target.style.borderColor = 'rgba(200,169,110,0.15)')}
                    required
                  />
                </div>
                <div>
                  <label
                    className="block text-xs mb-1.5 font-mono"
                    style={{ color: 'var(--silver)' }}
                  >
                    Email
                  </label>
                  <input
                    type="email"
                    className={inputCls}
                    style={inputStyle}
                    placeholder="you@example.com"
                    value={form.email}
                    onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                    onFocus={(e) => (e.target.style.borderColor = 'rgba(200,169,110,0.5)')}
                    onBlur={(e) => (e.target.style.borderColor = 'rgba(200,169,110,0.15)')}
                    required
                  />
                </div>
              </div>
              <div>
                <label
                  className="block text-xs mb-1.5 font-mono"
                  style={{ color: 'var(--silver)' }}
                >
                  Message
                </label>
                <textarea
                  className={inputCls}
                  style={{ ...inputStyle, resize: 'none' }}
                  rows={5}
                  placeholder="Tell me about your project..."
                  value={form.message}
                  onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
                  onFocus={(e) => (e.target.style.borderColor = 'rgba(200,169,110,0.5)')}
                  onBlur={(e) => (e.target.style.borderColor = 'rgba(200,169,110,0.15)')}
                  required
                />
              </div>

              {status === 'error' && (
                <p className="text-sm text-red-400">
                  Something went wrong. Please email me directly at ahmedshanwaz5@gmail.com
                </p>
              )}

              <button
                type="submit"
                disabled={status === 'loading'}
                className="w-full py-3 rounded-xl font-semibold text-sm transition-all hover:opacity-90 disabled:opacity-50"
                style={{
                  background: 'linear-gradient(135deg, #C8A96E, #E8C98A)',
                  color: '#080B10',
                }}
              >
                {status === 'loading' ? 'Sending...' : 'Send message →'}
              </button>
            </form>
          )}
        </div>

        {/* Direct contact */}
        <div className="mt-8 flex flex-wrap justify-center gap-6 text-sm" style={{ color: 'var(--silver)' }}>
          <a
            href="mailto:ahmedshanwaz5@gmail.com"
            className="hover:text-white transition-colors"
          >
            📧 ahmedshanwaz5@gmail.com
          </a>
          <a
            href="https://github.com/Shanwazmojaloy"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-white transition-colors"
          >
            🐙 GitHub
          </a>
        </div>
      </div>
    </section>
  )
}
