'use client'

const PROJECTS = [
  {
    title: 'Hotel Fountain CRM',
    description: 'Full-stack hotel management system with real-time room tracking, billing, reservations, and multi-role access control. Built for Bangladesh hospitality industry.',
    tags: ['Next.js', 'Supabase', 'TypeScript', 'Tailwind'],
    emoji: '🏨',
    link: '#',
    github: '#',
    featured: true,
  },
  {
    title: 'HotelOS SaaS Platform',
    description: 'White-label hotel CRM SaaS with multi-tenancy, Stripe subscriptions, custom branding, and per-tenant isolated databases.',
    tags: ['Next.js', 'Stripe', 'Supabase', 'Multi-tenant'],
    emoji: '🚀',
    link: '#',
    github: '#',
    featured: true,
  },
  {
    title: 'Developer Portfolio',
    description: 'This portfolio — built with Next.js 15, Tailwind CSS, and TypeScript. Features a typewriter hero, dark luxury aesthetic, and contact form.',
    tags: ['Next.js 15', 'TypeScript', 'Tailwind CSS'],
    emoji: '💼',
    link: '#',
    github: 'https://github.com/Shanwazmojaloy/folio',
    featured: false,
  },
]

export default function ProjectsSection() {
  return (
    <section id="projects" className="py-24 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-16">
          <p
            className="text-xs tracking-widest uppercase mb-3 font-mono"
            style={{ color: 'var(--gold)' }}
          >
            Selected work
          </p>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Projects
          </h2>
          <p style={{ color: 'var(--silver)' }} className="max-w-lg">
            Things I&apos;ve built — from side projects to production systems used by real businesses.
          </p>
        </div>

        {/* Projects grid */}
        <div className="grid gap-6">
          {PROJECTS.filter((p) => p.featured).map((project) => (
            <div
              key={project.title}
              className="group rounded-2xl p-8 border transition-all duration-300 hover:-translate-y-1"
              style={{
                background: 'var(--bg2)',
                borderColor: 'rgba(200,169,110,0.1)',
                boxShadow: 'none',
              }}
              onMouseEnter={(e) => {
                ;(e.currentTarget as HTMLElement).style.borderColor =
                  'rgba(200,169,110,0.3)'
                ;(e.currentTarget as HTMLElement).style.boxShadow =
                  '0 12px 40px rgba(200,169,110,0.08)'
              }}
              onMouseLeave={(e) => {
                ;(e.currentTarget as HTMLElement).style.borderColor =
                  'rgba(200,169,110,0.1)'
                ;(e.currentTarget as HTMLElement).style.boxShadow = 'none'
              }}
            >
              <div className="flex items-start justify-between gap-4 flex-wrap">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-3xl">{project.emoji}</span>
                    <h3 className="text-xl font-semibold">{project.title}</h3>
                  </div>
                  <p className="mb-4 leading-relaxed" style={{ color: 'var(--silver)' }}>
                    {project.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map((tag) => (
                      <span
                        key={tag}
                        className="text-xs px-3 py-1 rounded-full font-mono"
                        style={{
                          background: 'rgba(200,169,110,0.08)',
                          border: '1px solid rgba(200,169,110,0.15)',
                          color: 'var(--gold)',
                        }}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="flex gap-3 flex-shrink-0">
                  {project.github && project.github !== '#' && (
                    <a
                      href={project.github}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm px-4 py-2 rounded-lg border transition-all hover:opacity-80"
                      style={{
                        borderColor: 'rgba(255,255,255,0.1)',
                        color: 'var(--silver)',
                      }}
                    >
                      GitHub ↗
                    </a>
                  )}
                  {project.link && project.link !== '#' && (
                    <a
                      href={project.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm px-4 py-2 rounded-lg font-medium transition-all hover:opacity-90"
                      style={{
                        background: 'linear-gradient(135deg, #C8A96E, #E8C98A)',
                        color: '#080B10',
                      }}
                    >
                      Live ↗
                    </a>
                  )}
                </div>
              </div>
            </div>
          ))}

          {/* Smaller projects */}
          <div className="grid md:grid-cols-2 gap-6 mt-2">
            {PROJECTS.filter((p) => !p.featured).map((project) => (
              <div
                key={project.title}
                className="rounded-2xl p-6 border transition-all duration-300 hover:-translate-y-1"
                style={{
                  background: 'var(--bg2)',
                  borderColor: 'rgba(200,169,110,0.08)',
                }}
              >
                <span className="text-2xl mb-3 block">{project.emoji}</span>
                <h3 className="font-semibold mb-2">{project.title}</h3>
                <p className="text-sm mb-4 leading-relaxed" style={{ color: 'var(--silver)' }}>
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-xs px-2 py-1 rounded-full font-mono"
                      style={{
                        background: 'rgba(200,169,110,0.06)',
                        color: 'var(--silver)',
                      }}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
