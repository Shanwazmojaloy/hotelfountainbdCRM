'use client'

const SKILLS = {
  'Frontend': ['React', 'Next.js', 'TypeScript', 'Tailwind CSS', 'Framer Motion'],
  'Backend': ['Node.js', 'PostgreSQL', 'Supabase', 'REST APIs', 'Edge Functions'],
  'Tools': ['Git', 'Vercel', 'Stripe', 'Figma', 'VS Code'],
  'Learning': ['Rust', 'Three.js', 'WebGL'],
}

export default function AboutSection() {
  return (
    <>
      {/* ABOUT */}
      <section
        id="about"
        className="py-24 px-6"
        style={{
          background:
            'linear-gradient(180deg, transparent 0%, rgba(200,169,110,0.03) 50%, transparent 100%)',
        }}
      >
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <p
                className="text-xs tracking-widest uppercase mb-3 font-mono"
                style={{ color: 'var(--gold)' }}
              >
                About me
              </p>
              <h2 className="text-4xl md:text-5xl font-bold mb-6">
                I build things
                <br />
                <span
                  style={{
                    background: 'linear-gradient(135deg, #C8A96E, #E8C98A)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                  }}
                >
                  for the web.
                </span>
              </h2>
              <div className="space-y-4 text-base leading-relaxed" style={{ color: 'var(--silver)' }}>
                <p>
                  I&apos;m Shanwaz Ahmed, a full-stack developer based in Dhaka, Bangladesh.
                  I love turning complex problems into simple, beautiful, and intuitive digital products.
                </p>
                <p>
                  My focus is on building fast, accessible, and production-ready web applications —
                  from landing pages to full SaaS platforms. I care deeply about user experience
                  and clean architecture.
                </p>
                <p>
                  When I&apos;m not coding, I&apos;m exploring new technologies, contributing to
                  open source, or thinking about product ideas.
                </p>
              </div>

              <div className="mt-8 flex gap-4 flex-wrap">
                <a
                  href="https://github.com/Shanwazmojaloy"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm px-4 py-2 rounded-lg border transition-all hover:opacity-80"
                  style={{ borderColor: 'rgba(200,169,110,0.2)', color: 'var(--gold)' }}
                >
                  GitHub ↗
                </a>
                <a
                  href="mailto:ahmedshanwaz5@gmail.com"
                  className="text-sm px-4 py-2 rounded-lg border transition-all hover:opacity-80"
                  style={{ borderColor: 'rgba(255,255,255,0.1)', color: 'var(--silver)' }}
                >
                  Email me
                </a>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-4">
              {[
                { value: '3+', label: 'Years coding' },
                { value: '10+', label: 'Projects shipped' },
                { value: '100%', label: 'Remote-ready' },
                { value: '∞', label: 'Coffee consumed' },
              ].map((stat) => (
                <div
                  key={stat.label}
                  className="rounded-2xl p-6 border text-center"
                  style={{
                    background: 'var(--bg2)',
                    borderColor: 'rgba(200,169,110,0.08)',
                  }}
                >
                  <div
                    className="text-4xl font-bold font-mono mb-1"
                    style={{ color: 'var(--gold)' }}
                  >
                    {stat.value}
                  </div>
                  <div className="text-sm" style={{ color: 'var(--silver)' }}>
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* SKILLS */}
      <section id="skills" className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <p
            className="text-xs tracking-widest uppercase mb-3 font-mono"
            style={{ color: 'var(--gold)' }}
          >
            Tech stack
          </p>
          <h2 className="text-4xl md:text-5xl font-bold mb-12">Skills</h2>

          <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-6">
            {Object.entries(SKILLS).map(([category, skills]) => (
              <div
                key={category}
                className="rounded-2xl p-6 border"
                style={{
                  background: 'var(--bg2)',
                  borderColor: 'rgba(200,169,110,0.08)',
                }}
              >
                <h3
                  className="text-xs font-mono tracking-widest uppercase mb-4"
                  style={{ color: 'var(--gold)' }}
                >
                  {category}
                </h3>
                <ul className="space-y-2">
                  {skills.map((skill) => (
                    <li
                      key={skill}
                      className="text-sm flex items-center gap-2"
                      style={{ color: 'var(--silver)' }}
                    >
                      <span style={{ color: 'var(--gold)' }}>›</span>
                      {skill}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}
