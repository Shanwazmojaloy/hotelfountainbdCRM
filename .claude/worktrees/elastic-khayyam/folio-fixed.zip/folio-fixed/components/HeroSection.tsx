'use client'

import { useState, useEffect } from 'react'

const ROLES = [
  'Full-Stack Developer',
  'UI/UX Designer',
  'Open Source Builder',
  'Product Engineer',
]

export default function HeroSection() {
  const [displayText, setDisplayText] = useState('')
  const [roleIndex, setRoleIndex] = useState(0)
  const [isDeleting, setIsDeleting] = useState(false)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (!mounted) return

    const current = ROLES[roleIndex]
    const speed = isDeleting ? 40 : 80

    const timeout = setTimeout(() => {
      if (!isDeleting) {
        if (displayText.length < current.length) {
          setDisplayText(current.slice(0, displayText.length + 1))
        } else {
          setTimeout(() => setIsDeleting(true), 1800)
        }
      } else {
        if (displayText.length > 0) {
          setDisplayText(current.slice(0, displayText.length - 1))
        } else {
          setIsDeleting(false)
          setRoleIndex((i) => (i + 1) % ROLES.length)
        }
      }
    }, speed)

    return () => clearTimeout(timeout)
  }, [displayText, isDeleting, roleIndex, mounted])

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center px-6 overflow-hidden"
    >
      {/* Background gradient */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse 80% 60% at 50% 0%, rgba(200,169,110,0.10) 0%, transparent 70%)',
        }}
      />

      {/* Grid pattern */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage:
            'linear-gradient(rgba(200,169,110,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(200,169,110,0.04) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
        }}
      />

      <div className="relative z-10 max-w-4xl mx-auto text-center">
        {/* Available badge */}
        <div
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full border mb-8 text-sm"
          style={{
            background: 'rgba(200,169,110,0.08)',
            borderColor: 'rgba(200,169,110,0.2)',
            color: 'var(--gold)',
          }}
        >
          <span
            className="w-2 h-2 rounded-full"
            style={{ background: '#4ECBA3', animation: 'shimmer 2s ease infinite' }}
          />
          Available for new projects
        </div>

        {/* Name */}
        <h1 className="font-sans font-bold mb-4" style={{ fontSize: 'clamp(2.5rem, 7vw, 5rem)', lineHeight: 1.1 }}>
          <span style={{ color: 'white' }}>Hi, I&apos;m </span>
          <span
            style={{
              background: 'linear-gradient(135deg, #C8A96E, #E8C98A)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            Shanwaz
          </span>
        </h1>

        {/* Typewriter */}
        <div className="mb-6 h-10 flex items-center justify-center">
          <span
            className="text-xl md:text-2xl font-mono cursor-blink"
            style={{ color: 'var(--silver)' }}
          >
            {displayText}
          </span>
        </div>

        {/* Description */}
        <p
          className="text-lg max-w-2xl mx-auto mb-10 leading-relaxed"
          style={{ color: 'var(--silver)' }}
        >
          I build fast, beautiful web products — from pixel-perfect interfaces to
          robust backend systems. Passionate about clean code, great UX, and shipping things that matter.
        </p>

        {/* CTAs */}
        <div className="flex flex-wrap gap-4 justify-center">
          <a
            href="#projects"
            className="px-8 py-3 rounded-xl font-semibold transition-all duration-200 hover:opacity-90 hover:-translate-y-0.5"
            style={{
              background: 'linear-gradient(135deg, #C8A96E, #E8C98A)',
              color: '#080B10',
              boxShadow: '0 8px 32px rgba(200,169,110,0.25)',
            }}
          >
            View my work
          </a>
          <a
            href="#contact"
            className="px-8 py-3 rounded-xl font-medium transition-all duration-200 hover:opacity-80 border"
            style={{
              background: 'rgba(255,255,255,0.05)',
              borderColor: 'rgba(255,255,255,0.1)',
              color: 'white',
            }}
          >
            Get in touch
          </a>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2">
          <div
            className="w-6 h-10 rounded-full border-2 flex items-start justify-center pt-2"
            style={{ borderColor: 'rgba(200,169,110,0.3)' }}
          >
            <div
              className="w-1 h-2 rounded-full"
              style={{
                background: 'var(--gold)',
                animation: 'fadeUp 1.5s ease infinite alternate',
              }}
            />
          </div>
        </div>
      </div>
    </section>
  )
}
