'use client'
export { default } from './HotelApp'
