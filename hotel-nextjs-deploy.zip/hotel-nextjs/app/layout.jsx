export const metadata = {
  title: 'Hotel Fountain',
  description: 'Luxury Hotel Management System',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, padding: 0, background: '#0C1118' }}>{children}</body>
    </html>
  )
}
