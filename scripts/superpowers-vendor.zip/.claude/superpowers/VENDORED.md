# Superpowers (vendored)

| | |
|---|---|
| Upstream | https://github.com/obra/superpowers |
| Version | 6.3.0 |
| Commit | b36e082 |
| Vendored on | 2026-08-15 |
| License | MIT (see LICENSE) |

## What landed where

| Path | Contents |
|---|---|
| `.claude/skills/*/SKILL.md` | 14 superpowers skills, auto-discovered by Claude Code in this repo |
| `.claude/superpowers/hooks/` | upstream session-start hook + hooks.json (NOT wired up — see below) |
| `.claude/superpowers/claude-plugin/` | upstream plugin manifest, kept for reference |

## Preferred install (keeps itself updated)

Vendored copies go stale. In Claude Code:

```
/plugin marketplace add obra/superpowers
/plugin install superpowers@superpowers-dev
```

If you do that, delete `.claude/skills/` here to avoid two copies of the same skills competing.

## Wiring the session-start hook (optional)

The vendored skills work without hooks — Claude Code discovers `.claude/skills/*/SKILL.md` on its own. The hook only adds the "always read using-superpowers first" nudge. To enable it, merge `.claude/superpowers/hooks/hooks.json` into `.claude/settings.json` and fix the `\$CLAUDE_PLUGIN_ROOT` paths to point at `.claude/superpowers`.

## Updating

```powershell
git clone --depth 1 https://github.com/obra/superpowers.git $env:TEMP\sp
robocopy $env:TEMP\sp\skills ".claude\skills" /MIR
```
